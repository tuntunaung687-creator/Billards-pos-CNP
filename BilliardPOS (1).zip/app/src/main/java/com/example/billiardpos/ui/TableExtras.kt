package com.example.billiardpos.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.billiardpos.data.MarkerPerson
import com.example.billiardpos.data.MarkerStint
import com.example.billiardpos.data.TableItem
import com.example.billiardpos.util.Billing
import com.example.billiardpos.util.Fmt

/** မာကာ card: pick a named marker to start; each working marker has his own stop button. */
@Composable
fun MarkerCard(
    stints: List<MarkerStint>,
    people: List<MarkerPerson>,
    busyNames: Set<String>,
    now: Long,
    rate: Int,
    enabled: Boolean,
    onAdd: (String) -> Unit,
    onRemove: (MarkerStint) -> Unit,
    onSwap: (MarkerStint, String) -> Unit
) {
    var picking by remember { mutableStateOf(false) }
    var swapOf by remember { mutableStateOf<MarkerStint?>(null) }
    val working = stints.filter { it.endTime == null }
    val charge = Billing.marker(stints, now)
    val available = people.filter { it.active && it.name !in busyNames }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("မာကာ", fontWeight = FontWeight.Bold)
                    Text(
                        "တစ်နာရီ ${Fmt.ks(rate)}" +
                            if (stints.isNotEmpty()) "  •  ${Fmt.ks(charge.amount)}" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                OutlinedButton(onClick = { picking = true }, enabled = enabled) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Text("မာကာ ထည့်ရန်")
                }
            }
            working.forEach { s ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.markerName.ifBlank { "(အမည်မရှိ)" }, fontWeight = FontWeight.Medium)
                        Text(
                            "${Fmt.time(s.startTime)} မှ  •  ${Fmt.hm(Billing.minutes(s.startTime, now))}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = { swapOf = s; picking = true }) { Text("လဲမည်") }
                    TextButton(onClick = { onRemove(s) }) { Text("ရပ်မည်") }
                }
            }
            val lines = Billing.markerLines(stints, now)
            if (lines.isNotEmpty()) {
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                lines.forEach { l ->
                    Row {
                        Text(
                            "${l.name.ifBlank { "(အမည်မရှိ)" }}  •  ${Fmt.hm(l.minutes)}",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        Text(Fmt.ks(l.amount), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    if (picking) {
        AlertDialog(
            onDismissRequest = { picking = false; swapOf = null },
            title = { Text(if (swapOf != null) "လဲမည့် မာကာ ရွေးပါ" else "မာကာ ရွေးပါ") },
            text = {
                if (available.isEmpty()) {
                    Text("ရွေးစရာ မာကာ မရှိပါ။ Admin က ဆက်တင်တွင် မာကာအမည် ထည့်ပါ (သို့) အားလုံး အလုပ်ဝင်နေပါသည်။")
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        available.forEach { p ->
                            TextButton(
                                onClick = {
                                    val old = swapOf
                                    if (old != null) onSwap(old, p.name) else onAdd(p.name)
                                    picking = false
                                    swapOf = null
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(p.name) }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { picking = false; swapOf = null }) { Text("ပိတ်မည်") } }
        )
    }
}

/** Type the exact quantity of a line, e.g. 2 shown but the guest only ordered 1. */
@Composable
fun QtyDialog(
    item: TableItem,
    onSet: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(item.qty.toString()) }
    val qty = text.toIntOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(item.name) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField(
                    value = text,
                    label = "အရေအတွက် (0 ဆိုလျှင် ဖယ်ရှားမည်)",
                    onChange = { text = it.take(4) },
                    modifier = Modifier.fillMaxWidth()
                )
                if (qty != null) {
                    Text(
                        "${Fmt.ks(item.price)} x $qty = ${Fmt.ks(item.price * qty)}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = qty != null,
                onClick = { onSet(qty ?: item.qty) }
            ) { Text("သိမ်းမည်") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("မလုပ်တော့ပါ") } }
    )
}

/** Pick an idle table to move the running bill to (guest changes table). */
@Composable
fun MoveTableDialog(
    candidates: List<com.example.billiardpos.data.BilliardTable>,
    onPick: (com.example.billiardpos.data.BilliardTable) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ခုံပြောင်းမည် - ခုံအသစ် ရွေးပါ") },
        text = {
            if (candidates.isEmpty()) {
                Text("လွတ်နေသော ခုံ မရှိပါ")
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    candidates.forEach { t ->
                        TextButton(onClick = { onPick(t) }, modifier = Modifier.fillMaxWidth()) {
                            Text(t.name)
                        }
                    }
                    Text(
                        "အချိန်၊ ပစ္စည်း၊ မာကာ အားလုံး ခုံအသစ်သို့ ပါသွားပါမည်။",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("မလုပ်တော့ပါ") } }
    )
}

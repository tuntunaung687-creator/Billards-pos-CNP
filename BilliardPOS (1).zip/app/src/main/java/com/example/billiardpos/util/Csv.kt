package com.example.billiardpos.util

import com.example.billiardpos.data.PeriodSummary
import com.example.billiardpos.data.Sale

/** CSV text for Excel / Google Sheets. Starts with a UTF-8 BOM so Myanmar text opens correctly. */
object Csv {
    private const val BOM = "﻿"

    private fun esc(value: String): String =
        if (value.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) {
            "\"" + value.replace("\"", "\"\"") + "\""
        } else {
            value
        }

    private fun line(vararg cells: Any?): String =
        cells.joinToString(",") { esc(it?.toString() ?: "") } + "\r\n"

    fun bills(sales: List<Sale>): String = buildString {
        append(BOM)
        append(
            line(
                "ဘောက်ချာ အမှတ်", "ရက်စွဲ", "ခုံ", "စတင်ချိန်", "ပြီးဆုံးချိန်", "မိနစ်",
                "ခုံကြေး", "မာကာကြေး", "အခြားရောင်းရငွေ", "လျှော့ငွေ", "စုစုပေါင်း", "ဝန်ထမ်း", "စားပွဲထိုး"
            )
        )
        sales.forEach { s ->
            append(
                line(
                    s.id, Fmt.dateTime(s.createdAt), s.tableName,
                    s.startTime?.let { Fmt.time(it) }, Fmt.time(s.endTime), s.minutes,
                    s.playAmount, s.markerAmount, s.itemsAmount, s.discount, s.total, s.staffName, s.waiterName
                )
            )
        }
        append(
            line(
                "စုစုပေါင်း", "", "", "", "", "",
                sales.sumOf { it.playAmount }, sales.sumOf { it.markerAmount }, sales.sumOf { it.itemsAmount },
                sales.sumOf { it.discount }, sales.sumOf { it.total }, "", ""
            )
        )
    }

    fun summary(periodHeader: String, rows: List<PeriodSummary>, labelOf: (String) -> String): String =
        buildString {
            append(BOM)
            append(
                line(
                    periodHeader, "ဘောက်ချာ အရေအတွက်", "ခုံကြေး", "မာကာကြေး",
                    "အခြားရောင်းရငွေ", "လျှော့ငွေ", "စုစုပေါင်း"
                )
            )
            rows.forEach { r ->
                append(line(labelOf(r.period), r.billCount, r.play, r.marker, r.items, r.discount, r.total))
            }
            append(
                line(
                    "စုစုပေါင်း", rows.sumOf { it.billCount }, rows.sumOf { it.play },
                    rows.sumOf { it.marker }, rows.sumOf { it.items }, rows.sumOf { it.discount }, rows.sumOf { it.total }
                )
            )
        }
}

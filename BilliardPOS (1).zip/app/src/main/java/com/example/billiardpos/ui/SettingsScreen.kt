@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.billiardpos.ui

import android.Manifest
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(vm: PosViewModel, modifier: Modifier = Modifier) {
    val settings by vm.settings.collectAsStateWithLifecycle()

    // Local text state keeps the keyboard/IME (incl. Myanmar input) stable while typing.
    var shopName by remember { mutableStateOf(settings.shopName) }
    var footer by remember { mutableStateOf(settings.footer) }
    var syncUrl by remember { mutableStateOf(settings.syncUrl) }
    var syncToken by remember { mutableStateOf(settings.syncToken) }
    val syncStatus by vm.syncStatus.collectAsStateWithLifecycle()
    var bigRate by remember(settings.bigRate) { mutableStateOf(settings.bigRate.toString()) }
    var smallRate by remember(settings.smallRate) { mutableStateOf(settings.smallRate.toString()) }
    var markerRate by remember(settings.markerRate) { mutableStateOf(settings.markerRate.toString()) }
    var showPicker by remember { mutableStateOf(false) }
    var pendingRestore by remember { mutableStateOf<Uri?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) showPicker = true else vm.toast("Bluetooth ခွင့်ပြုချက် လိုအပ်ပါသည်")
    }
    val backupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) vm.backupTo(uri) }
    val restoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) pendingRestore = uri }

    fun openPicker() {
        if (vm.printer.hasPermission()) {
            showPicker = true
        } else {
            permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        }
    }

    val ratesChanged = markerRate != settings.markerRate.toString() ||
        bigRate != settings.bigRate.toString() ||
        smallRate != settings.smallRate.toString()

    Column(modifier.fillMaxSize()) {
        PosTopBar("ဆက်တင်")
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionTitle("ဆိုင်အချက်အလက်")
            OutlinedTextField(
                value = shopName,
                onValueChange = { v ->
                    shopName = v
                    vm.updateSettings { it.copy(shopName = v) }
                },
                label = { Text("ဆိုင်အမည်") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = footer,
                onValueChange = { v ->
                    footer = v
                    vm.updateSettings { it.copy(footer = v) }
                },
                label = { Text("ဘောက်ချာအောက်ခြေ စာသား") },
                modifier = Modifier.fillMaxWidth()
            )

            HorizontalDivider()
            SectionTitle("ခုံကြေး ဈေးနှုန်း (တစ်နာရီ)")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                NumberField(
                    value = bigRate,
                    label = "၁၂ ပေ ခုံကြီး (Ks)",
                    onChange = { bigRate = it },
                    modifier = Modifier.weight(1f)
                )
                NumberField(
                    value = smallRate,
                    label = "၁၀ ပေ ခုံသေး (Ks)",
                    onChange = { smallRate = it },
                    modifier = Modifier.weight(1f)
                )
            }
            NumberField(
                value = markerRate,
                label = "မာကာကြေး (တစ်နာရီ၊ တစ်ယောက် Ks)",
                onChange = { markerRate = it },
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    vm.setRates(
                        bigRate.toIntOrNull() ?: 0,
                        smallRate.toIntOrNull() ?: 0,
                        markerRate.toIntOrNull() ?: 0
                    )
                },
                enabled = ratesChanged && bigRate.isNotBlank() && smallRate.isNotBlank() &&
                    markerRate.isNotBlank()
            ) { Text("ဈေးနှုန်း ပြောင်းမည်") }
            Text(
                "ဈေးနှုန်းပြောင်းလျှင် ခုံအားလုံးသို့ ချက်ချင်း သက်ရောက်ပါသည်။ ဆော့နေဆဲ ခုံများနှင့် ယခင်ဘောက်ချာများသည် မူလဈေးအတိုင်း ဆက်တွက်ပါမည်။",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider()
            SectionTitle("ဘောက်ချာ ပရင်တာ (Bluetooth)")
            Card(Modifier.fillMaxWidth()) {
                ListItem(
                    headlineContent = {
                        Text(
                            if (settings.printerAddress.isBlank()) "ပရင်တာ မရွေးရသေးပါ"
                            else settings.printerName
                        )
                    },
                    supportingContent = {
                        if (settings.printerAddress.isNotBlank()) Text(settings.printerAddress)
                    },
                    modifier = Modifier.clickable { openPicker() }
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { openPicker() }) { Text("ပရင်တာ ရွေးရန်") }
                OutlinedButton(
                    onClick = { vm.testPrint() },
                    enabled = settings.printerAddress.isNotBlank()
                ) {
                    Icon(Icons.Filled.Print, contentDescription = null)
                    Text("စမ်းပရင့်", modifier = Modifier.padding(start = 6.dp))
                }
            }

            Text("စက္ကူအကျယ်", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !settings.paper80,
                    onClick = { vm.updateSettings { it.copy(paper80 = false) } },
                    label = { Text("58 mm") }
                )
                FilterChip(
                    selected = settings.paper80,
                    onClick = { vm.updateSettings { it.copy(paper80 = true) } },
                    label = { Text("80 mm") }
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "ငွေရှင်းချိန်တွင် အလိုအလျောက် ပရင့်ထုတ်မည်",
                    modifier = Modifier.weight(1f)
                )
                Switch(
                    checked = settings.autoPrint,
                    onCheckedChange = { v -> vm.updateSettings { it.copy(autoPrint = v) } }
                )
            }
            Text(
                "ပရင်တာကို ဖုန်း၏ Bluetooth ဆက်တင်တွင် အရင် pair လုပ်ထားရပါမည်။",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider()
            SectionTitle("ဝန်ထမ်းများ")
            StaffSection(vm)

            HorizontalDivider()
            SectionTitle("စားပွဲထိုးများ")
            WaiterSection(vm)

            HorizontalDivider()
            SectionTitle("မာကာများ")
            MarkerPeopleSection(vm)

            HorizontalDivider()
            SectionTitle("Online - ပိုင်ရှင် အဝေးကကြည့်ရန် (Google Sheet)")
            OutlinedTextField(
                value = syncUrl,
                onValueChange = { v ->
                    syncUrl = v
                    vm.updateSettings { it.copy(syncUrl = v.trim()) }
                },
                label = { Text("Script လင့်ခ် (Web app URL)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = syncToken,
                onValueChange = { v ->
                    syncToken = v
                    vm.updateSettings { it.copy(syncToken = v.trim()) }
                },
                label = { Text("လျှို့ဝှက်စကားလုံး (Token)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { vm.syncNow(manual = true) },
                    enabled = syncUrl.isNotBlank()
                ) { Text("ယခု ပို့မည်") }
                OutlinedButton(
                    onClick = { vm.syncNow(manual = true, all = true) },
                    enabled = syncUrl.isNotBlank()
                ) { Text("အားလုံး ပြန်ပို့မည်") }
            }
            if (syncStatus.isNotBlank()) Text(syncStatus, style = MaterialTheme.typography.bodySmall)
            Text(
                "ငွေရှင်းပြီးတိုင်း ဘောက်ချာကို Google Sheet သို့ အလိုအလျောက် ပို့ပါသည်။ အင်တာနက်မရှိလျှင် နောက်ငွေရှင်းချိန်တွင် ကျန်သည်များ ပေါင်းပို့ပါမည်။ ပိုင်ရှင်က ဖုန်းထဲ Google Sheets app ဖြင့် ကြည့်ပါ။",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider()
            SectionTitle("Backup / ပြန်ယူခြင်း")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
                        backupLauncher.launch("BilliardPOS-backup-$stamp.json")
                    }
                ) { Text("Backup သိမ်းမည်") }
                OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("*/*")) }) {
                    Text("Backup မှ ပြန်ယူမည်")
                }
            }
            Text(
                "ခုံ၊ ပစ္စည်း၊ ဘောက်ချာမှတ်တမ်းအားလုံးကို ဖိုင်တစ်ခုအဖြစ် သိမ်းပါသည်။ ဖုန်းပြောင်းလျှင် သို့မဟုတ် app ဖျက်မီ Backup ကို Google Drive / ဖုန်းထဲတွင် သိမ်းထားပါ။",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    pendingRestore?.let { uri ->
        ConfirmDialog(
            title = "Backup မှ ပြန်ယူမည်လား?",
            text = "ယခု app ထဲရှိ ဒေတာအားလုံးကို Backup ဖိုင်ထဲက ဒေတာဖြင့် အစားထိုးပါမည်။",
            confirmLabel = "ပြန်ယူမည်",
            onConfirm = {
                pendingRestore = null
                vm.restoreFrom(uri)
            },
            onDismiss = { pendingRestore = null }
        )
    }

    if (showPicker) {
        val devices = remember { vm.printer.bondedDevices() }
        AlertDialog(
            onDismissRequest = { showPicker = false },
            title = { Text("ပရင်တာ ရွေးရန်") },
            text = {
                if (devices.isEmpty()) {
                    Text("Pair လုပ်ထားသော Bluetooth ကိရိယာ မတွေ့ပါ။ ဖုန်း Bluetooth ဆက်တင်တွင် ပရင်တာကို အရင် pair လုပ်ပါ။")
                } else {
                    Column {
                        devices.forEach { device ->
                            ListItem(
                                headlineContent = { Text(device.name) },
                                supportingContent = { Text(device.address) },
                                modifier = Modifier.clickable {
                                    vm.selectPrinter(device)
                                    showPicker = false
                                }
                            )
                            HorizontalDivider()
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPicker = false }) { Text("ပိတ်မည်") } }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
    )
}

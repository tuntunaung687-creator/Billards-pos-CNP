@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.billiardpos.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.billiardpos.data.Product
import com.example.billiardpos.util.Fmt

@Composable
fun ProductsScreen(vm: PosViewModel, modifier: Modifier = Modifier) {
    val products by vm.products.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<Product?>(null) }
    var adding by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val shown = products.filter {
        query.isBlank() || it.name.contains(query.trim(), ignoreCase = true) ||
            it.category.contains(query.trim(), ignoreCase = true)
    }

    Column(modifier.fillMaxSize()) {
        PosTopBar(
            title = "ပစ္စည်းများ (${products.size})",
            actions = {
                TextButton(
                    onClick = { adding = true },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) { Text("+ ထည့်ရန်") }
            }
        )
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("ရှာရန် (အမည် / အမျိုးအစား)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
        )
        Box(Modifier.fillMaxSize()) {
            if (products.isEmpty()) {
                Text(
                    "ပစ္စည်း မရှိသေးပါ။\n+ ခလုတ်ကို နှိပ်၍ ထည့်ပါ။",
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
            }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                items(shown, key = { it.id }) { product ->
                    val lowStock = product.trackStock && product.stock <= 5
                    ListItem(
                        headlineContent = { Text(product.name, fontWeight = FontWeight.Medium) },
                        supportingContent = {
                            val parts = listOfNotNull(
                                product.category.ifBlank { null },
                                if (product.trackStock) "လက်ကျန် ${product.stock}" else null
                            )
                            if (parts.isNotEmpty()) {
                                Text(
                                    parts.joinToString("  •  "),
                                    color = if (lowStock) {
                                        MaterialTheme.colorScheme.error
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                        },
                        trailingContent = {
                            Text(Fmt.ks(product.price), fontWeight = FontWeight.Bold)
                        },
                        modifier = Modifier.clickable { editing = product }
                    )
                    HorizontalDivider()
                }
            }
            FloatingActionButton(
                onClick = { adding = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "ပစ္စည်းထည့်ရန်")
            }
        }
    }

    if (adding) {
        ProductDialog(
            initial = null,
            onSave = {
                vm.saveProduct(it)
                adding = false
            },
            onDelete = null,
            onDismiss = { adding = false }
        )
    }
    editing?.let { product ->
        ProductDialog(
            initial = product,
            onSave = {
                vm.saveProduct(it)
                editing = null
            },
            onDelete = {
                vm.deleteProduct(product)
                editing = null
            },
            onDismiss = { editing = null }
        )
    }
}

@Composable
private fun ProductDialog(
    initial: Product?,
    onSave: (Product) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var price by remember { mutableStateOf(initial?.price?.toString() ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "") }
    var trackStock by remember { mutableStateOf(initial?.trackStock ?: false) }
    var stock by remember { mutableStateOf(initial?.stock?.toString() ?: "0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "ပစ္စည်းအသစ်" else "ပစ္စည်း ပြင်ရန်") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("အမည်") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                NumberField(
                    value = price,
                    label = "ဈေးနှုန်း (Ks)",
                    onChange = { price = it },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("အမျိုးအစား (ရွေးချယ်စရာ)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("လက်ကျန် ရေတွက်မည်", modifier = Modifier.weight(1f))
                    Switch(checked = trackStock, onCheckedChange = { trackStock = it })
                }
                if (trackStock) {
                    NumberField(
                        value = stock,
                        label = "လက်ကျန် အရေအတွက်",
                        onChange = { stock = it },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text("ဤပစ္စည်းကို ဖျက်မည်", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        (initial ?: Product(name = "", price = 0)).copy(
                            name = name.trim(),
                            price = price.toIntOrNull() ?: 0,
                            category = category.trim(),
                            trackStock = trackStock,
                            stock = if (trackStock) stock.toIntOrNull() ?: 0 else 0
                        )
                    )
                },
                enabled = name.isNotBlank() && price.isNotBlank()
            ) { Text("သိမ်းမည်") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("မလုပ်တော့ပါ") } }
    )
}

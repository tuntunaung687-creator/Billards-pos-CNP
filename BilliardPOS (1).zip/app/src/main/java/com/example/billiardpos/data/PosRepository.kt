package com.example.billiardpos.data

import androidx.room.withTransaction
import com.example.billiardpos.util.Billing
import com.example.billiardpos.util.MarkerCharge
import com.example.billiardpos.util.Pin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PosRepository(private val db: AppDatabase) {
    private val tableDao = db.tableDao()
    private val productDao = db.productDao()
    private val itemDao = db.itemDao()
    private val saleDao = db.saleDao()
    private val staffDao = db.staffDao()
    private val markerDao = db.markerDao()
    private val markerPersonDao = db.markerPersonDao()
    private val markerPayDao = db.markerPayDao()
    private val waiterDao = db.waiterDao()

    fun observeTables() = tableDao.observeAll()
    fun observeAllItems() = itemDao.observeAll()
    fun observeMarkers() = markerDao.observeAll()
    fun observeMarkerPeople() = markerPersonDao.observeAll()
    fun observeWaiters() = waiterDao.observeAll()
    suspend fun markerPayFor(saleId: Long) = markerPayDao.forSale(saleId)
    fun observeMarkerPay(from: Long, to: Long) = markerPayDao.observeSummary(from, to)
    fun observeProducts() = productDao.observeActive()
    fun observeSales(from: Long, to: Long) = saleDao.observeBetween(from, to)
    fun observeTopProducts(from: Long, to: Long) = saleDao.observeTopProducts(from, to)
    fun observeSummary(pattern: String, offset: Long, from: Long, to: Long) =
        saleDao.observeSummary(pattern, offset, from, to)

    suspend fun salesAfter(after: Long) = saleDao.salesAfter(after)
    suspend fun markerPayAfter(after: Long) = markerPayDao.after(after)
    suspend fun getSale(id: Long) = saleDao.getSale(id)
    suspend fun getSaleItems(saleId: Long) = saleDao.itemsFor(saleId)

    // ---- Backup ---------------------------------------------------------

    // ---- Staff ----------------------------------------------------------

    fun observeStaff() = staffDao.observeAll()
    fun observeStaffCount() = staffDao.observeCount()

    suspend fun createStaff(name: String, role: Role, pin: String): Staff {
        val salt = Pin.newSalt()
        val hash = withContext(Dispatchers.Default) { Pin.hash(pin, salt) }
        val staff = Staff(name = name, role = role.name, salt = salt, pinHash = hash)
        return staff.copy(id = staffDao.insert(staff))
    }

    /** Returns the staff member when the PIN is right and the account is active, else null. */
    suspend fun verifyPin(staffId: Long, pin: String): Staff? {
        val staff = staffDao.get(staffId) ?: return null
        if (!staff.active) return null
        val ok = withContext(Dispatchers.Default) { Pin.matches(pin, staff.salt, staff.pinHash) }
        return if (ok) staff else null
    }

    suspend fun changePin(staffId: Long, pin: String) {
        val staff = staffDao.get(staffId) ?: return
        val salt = Pin.newSalt()
        val hash = withContext(Dispatchers.Default) { Pin.hash(pin, salt) }
        staffDao.update(staff.copy(salt = salt, pinHash = hash))
    }

    /** Returns false when it would leave the shop without any active admin. */
    suspend fun setStaffActive(staffId: Long, active: Boolean): Boolean = db.withTransaction {
        val staff = staffDao.get(staffId) ?: return@withTransaction false
        val lastAdmin = !active && staff.active && staff.role == Role.ADMIN.name &&
            staffDao.activeAdminCount() <= 1
        if (lastAdmin) return@withTransaction false
        staffDao.update(staff.copy(active = active))
        true
    }

    // ---- Backup ---------------------------------------------------------

    suspend fun exportBackup(settings: AppSettings, now: Long): String =
        Backup.export(db, settings, now)

    suspend fun importBackup(text: String): Backup.Restored = Backup.restore(db, text)

    // ---- Tables ---------------------------------------------------------

    suspend fun seedIfEmpty(counterName: String, tablePrefix: String, bigRate: Int, smallRate: Int) {
        if (tableDao.count() > 0) return
        val plan = listOf(
            TableSize.BIG to bigRate,
            TableSize.BIG to bigRate,
            TableSize.SMALL to smallRate,
            TableSize.SMALL to smallRate
        )
        plan.forEachIndexed { i, (size, rate) ->
            tableDao.insert(
                BilliardTable(
                    name = "$tablePrefix ${i + 1}",
                    ratePerHour = rate,
                    sortOrder = i,
                    size = size.name
                )
            )
        }
        tableDao.insert(
            BilliardTable(name = counterName, ratePerHour = 0, isCounter = true, sortOrder = 999)
        )
    }

    suspend fun addTable(name: String, size: TableSize, ratePerHour: Int) {
        val order = tableDao.maxSortOrder() + 1
        tableDao.insert(
            BilliardTable(name = name, ratePerHour = ratePerHour, sortOrder = order, size = size.name)
        )
    }

    suspend fun updateTable(table: BilliardTable) = tableDao.update(table)

    /** Changes the hourly rate of every table of [size]. Running sessions keep their locked rate. */
    suspend fun applyRate(size: TableSize, rate: Int) = tableDao.setRateForSize(size.name, rate)

    /** Returns false when the table is in use and therefore cannot be deleted. */
    suspend fun deleteTable(table: BilliardTable): Boolean = db.withTransaction {
        val fresh = tableDao.get(table.id) ?: return@withTransaction true
        if (fresh.isCounter || fresh.startTime != null || itemDao.getFor(fresh.id).isNotEmpty()) {
            return@withTransaction false
        }
        tableDao.delete(fresh)
        true
    }

    /** Starts the clock and locks the table's current hourly rate for this session. */
    suspend fun startTable(id: Long, now: Long) = db.withTransaction {
        val table = tableDao.get(id) ?: return@withTransaction
        if (table.isCounter || table.startTime != null) return@withTransaction
        tableDao.startSession(id, now, table.ratePerHour)
    }

    // ---- Running bill ---------------------------------------------------

    /** Adds one unit of [product]. Returns false when tracked stock is insufficient. */
    suspend fun addItem(tableId: Long, product: Product): Boolean = db.withTransaction {
        val fresh = productDao.get(product.id) ?: return@withTransaction false
        val existing = itemDao.find(tableId, fresh.id)
        val newQty = (existing?.qty ?: 0) + 1
        if (fresh.trackStock && newQty > fresh.stock) return@withTransaction false
        if (existing == null) {
            itemDao.insert(
                TableItem(
                    tableId = tableId,
                    productId = fresh.id,
                    name = fresh.name,
                    price = fresh.price,
                    qty = 1
                )
            )
        } else {
            itemDao.update(existing.copy(qty = newQty))
        }
        true
    }

    /** Changes quantity by [delta]; removes the line at zero. Returns false on insufficient stock. */
    suspend fun changeQty(item: TableItem, delta: Int): Boolean = db.withTransaction {
        val newQty = item.qty + delta
        if (newQty <= 0) {
            itemDao.deleteById(item.id)
            return@withTransaction true
        }
        if (delta > 0) {
            val product = productDao.get(item.productId)
            if (product != null && product.trackStock && newQty > product.stock) {
                return@withTransaction false
            }
        }
        itemDao.update(item.copy(qty = newQty))
        true
    }

    /** Discards the running bill without recording a sale. */
    suspend fun cancelSession(tableId: Long) = db.withTransaction {
        itemDao.clearFor(tableId)
        markerDao.clearFor(tableId)
        tableDao.endSession(tableId)
    }

    /**
     * Moves the whole running bill (clock, locked rate, items, markers) from [fromId] to the
     * idle table [toId]. Returns false when the move is not allowed.
     */
    suspend fun moveTable(fromId: Long, toId: Long): Boolean = db.withTransaction {
        val from = tableDao.get(fromId) ?: return@withTransaction false
        val to = tableDao.get(toId) ?: return@withTransaction false
        val start = from.startTime ?: return@withTransaction false
        if (from.isCounter || to.isCounter || fromId == toId) return@withTransaction false
        if (to.startTime != null || itemDao.getFor(toId).isNotEmpty()) return@withTransaction false
        tableDao.startSession(toId, start, from.billingRate())
        itemDao.moveAll(fromId, toId)
        markerDao.moveAll(fromId, toId)
        tableDao.endSession(fromId)
        true
    }

    // ---- Markers (မာကာ) -------------------------------------------------

    /** A marker starts working now; the hourly [rate] is locked for him. */
    suspend fun addMarker(tableId: Long, name: String, rate: Int, now: Long) {
        markerDao.insert(MarkerStint(tableId = tableId, startTime = now, rate = rate, markerName = name))
    }

    suspend fun createMarkerPerson(name: String) {
        markerPersonDao.insert(MarkerPerson(name = name))
    }

    suspend fun renameMarkerPerson(id: Long, name: String) {
        val p = markerPersonDao.get(id) ?: return
        markerPersonDao.update(p.copy(name = name))
    }

    suspend fun createWaiter(name: String) {
        waiterDao.insert(Waiter(name = name))
    }

    suspend fun renameWaiter(id: Long, name: String) {
        val w = waiterDao.get(id) ?: return
        waiterDao.update(w.copy(name = name))
    }

    suspend fun setWaiterActive(id: Long, active: Boolean) {
        val w = waiterDao.get(id) ?: return
        waiterDao.update(w.copy(active = active))
    }

    /** Marker [stint] stops and [newName] takes over at the same moment (e.g. A is ill, B steps in). */
    suspend fun swapMarker(stint: MarkerStint, newName: String, rate: Int, now: Long) =
        db.withTransaction {
            removeMarker(stint, now)
            markerDao.insert(
                MarkerStint(tableId = stint.tableId, startTime = now, rate = rate, markerName = newName)
            )
        }

    suspend fun setMarkerPersonActive(id: Long, active: Boolean) {
        val p = markerPersonDao.get(id) ?: return
        markerPersonDao.update(p.copy(active = active))
    }

    /**
     * Stops the most recently added working marker. A stint shorter than a minute is treated as
     * an accidental tap and removed completely so it is not billed.
     */
    suspend fun removeMarker(stint: MarkerStint, now: Long) = db.withTransaction {
        val open = markerDao.getFor(stint.tableId).firstOrNull { it.id == stint.id && it.endTime == null }
            ?: return@withTransaction
        if (now - open.startTime < 60_000L) markerDao.deleteById(open.id)
        else markerDao.update(open.copy(endTime = now))
    }

    // ---- Exact quantity -------------------------------------------------

    /** Sets the quantity of a line to exactly [qty] (0 removes it). False on insufficient stock. */
    suspend fun setQty(item: TableItem, qty: Int): Boolean = db.withTransaction {
        if (qty <= 0) {
            itemDao.deleteById(item.id)
            return@withTransaction true
        }
        if (qty > item.qty) {
            val product = productDao.get(item.productId)
            if (product != null && product.trackStock && qty > product.stock) {
                return@withTransaction false
            }
        }
        itemDao.update(item.copy(qty = qty))
        true
    }

    // ---- Checkout -------------------------------------------------------

    /** Closes the running bill, stores it as a [Sale] and returns the sale id. */
    suspend fun checkout(
        tableId: Long,
        discount: Int,
        now: Long,
        staffName: String,
        waiterName: String = ""
    ): Long = db.withTransaction {
        val table = tableDao.get(tableId) ?: error("Table not found")
        val items = itemDao.getFor(tableId)
        val start = table.startTime
        val timed = !table.isCounter && start != null

        val minutes = if (timed && start != null) Billing.minutes(start, now) else 0
        val play = if (timed) Billing.playAmount(table.billingRate(), minutes) else 0
        val itemsAmount = items.sumOf { it.price * it.qty }
        val stints = markerDao.getFor(tableId)
        val marker = if (timed || stints.isNotEmpty()) Billing.marker(stints, now) else MarkerCharge(0, 0)
        val gross = play + marker.amount + itemsAmount
        val appliedDiscount = discount.coerceIn(0, gross)

        val saleId = saleDao.insertSale(
            Sale(
                tableName = table.name,
                startTime = if (table.isCounter) null else start,
                endTime = now,
                minutes = minutes,
                playAmount = play,
                markerAmount = marker.amount,
                markerMinutes = marker.minutes,
                itemsAmount = itemsAmount,
                discount = appliedDiscount,
                total = gross - appliedDiscount,
                createdAt = now,
                staffName = staffName,
                waiterName = waiterName
            )
        )
        saleDao.insertItems(
            items.map { SaleItem(saleId = saleId, name = it.name, price = it.price, qty = it.qty) }
        )
        markerPayDao.insertAll(
            Billing.markerLines(stints, now).filter { it.amount > 0 }.map {
                MarkerPay(
                    saleId = saleId,
                    markerName = it.name,
                    minutes = it.minutes,
                    amount = it.amount,
                    createdAt = now
                )
            }
        )
        items.forEach { productDao.decrementStock(it.productId, it.qty) }
        itemDao.clearFor(tableId)
        markerDao.clearFor(tableId)
        tableDao.endSession(tableId)
        saleId
    }

    // ---- Products -------------------------------------------------------

    suspend fun saveProduct(product: Product) {
        if (product.id == 0L) productDao.insert(product) else productDao.update(product)
    }
}

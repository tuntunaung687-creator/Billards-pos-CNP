package com.example.billiardpos.data

import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/**
 * Whole-shop backup as one JSON file: tables, products, running bills, sales history and
 * the shop/rate settings. Restoring replaces everything currently in the app.
 */
object Backup {
    private const val APP = "BilliardPOS"
    private const val VERSION = 1

    data class Restored(
        val shopName: String?,
        val footer: String?,
        val bigRate: Int?,
        val smallRate: Int?,
        val markerRate: Int? = null,
        /** True when the backup's staff accounts replaced the current ones (everyone must log in again). */
        val staffReplaced: Boolean = false
    )

    private class Parsed(
        val settings: Restored,
        val tables: List<BilliardTable>,
        val products: List<Product>,
        val tableItems: List<TableItem>,
        val sales: List<Sale>,
        val saleItems: List<SaleItem>,
        val markers: List<MarkerStint>,
        val markerPeople: List<MarkerPerson>,
        val waiters: List<Waiter>,
        val markerPays: List<MarkerPay>,
        /** Null for backups made before staff accounts existed. */
        val staff: List<Staff>?
    )

    suspend fun export(db: AppDatabase, s: AppSettings, now: Long): String = db.withTransaction {
        JSONObject()
            .put("app", APP)
            .put("version", VERSION)
            .put("exportedAt", now)
            .put(
                "settings",
                JSONObject()
                    .put("shopName", s.shopName)
                    .put("footer", s.footer)
                    .put("bigRate", s.bigRate)
                    .put("smallRate", s.smallRate)
                    .put("markerRate", s.markerRate)
            )
            .put("tables", db.tableDao().getAll().toJsonArray { it.toJson() })
            .put("products", db.productDao().getAll().toJsonArray { it.toJson() })
            .put("tableItems", db.itemDao().getAll().toJsonArray { it.toJson() })
            .put("sales", db.saleDao().getAllSales().toJsonArray { it.toJson() })
            .put("saleItems", db.saleDao().getAllSaleItems().toJsonArray { it.toJson() })
            .put("markers", db.markerDao().getAll().toJsonArray { it.toJson() })
            .put("markerPeople", db.markerPersonDao().getAll().toJsonArray { it.toJson() })
            .put("waiters", db.waiterDao().getAll().toJsonArray { it.toJson() })
            .put("markerPays", db.markerPayDao().getAll().toJsonArray { it.toJson() })
            .put("staff", db.staffDao().getAll().toJsonArray { it.toJson() })
            .toString(2)
    }

    /** Replaces all data with the backup. Throws [IllegalArgumentException] for a bad file. */
    suspend fun restore(db: AppDatabase, text: String): Restored {
        // Parse everything first: a bad file must never touch the current data.
        val parsed = try {
            parse(text)
        } catch (e: JSONException) {
            throw IllegalArgumentException("Backup ဖိုင်ပုံစံ မမှန်ပါ")
        }
        // Only swap staff accounts when the backup has them AND someone can still log in as admin.
        val replaceStaff = parsed.staff?.any { it.active && it.role == Role.ADMIN.name } == true
        db.withTransaction {
            db.markerDao().deleteAll()
            db.markerPersonDao().deleteAll()
            db.markerPayDao().deleteAll()
            db.itemDao().deleteAll()
            db.saleDao().deleteAllSaleItems()
            db.saleDao().deleteAllSales()
            db.tableDao().deleteAll()
            db.productDao().deleteAll()

            db.tableDao().insertAll(parsed.tables)
            db.productDao().insertAll(parsed.products)
            db.itemDao().insertAll(parsed.tableItems)
            db.markerDao().insertAll(parsed.markers)
            db.markerPersonDao().insertAll(parsed.markerPeople)
            db.waiterDao().deleteAll()
            db.waiterDao().insertAll(parsed.waiters)
            db.markerPayDao().insertAll(parsed.markerPays)
            db.saleDao().insertSales(parsed.sales)
            db.saleDao().insertItems(parsed.saleItems)
            if (replaceStaff) {
                db.staffDao().deleteAll()
                db.staffDao().insertAll(parsed.staff.orEmpty())
            }
        }
        return parsed.settings.copy(staffReplaced = replaceStaff)
    }

    private fun parse(text: String): Parsed {
        val root = JSONObject(text)
        require(root.optString("app") == APP) { "ဤဖိုင်သည် Billiard POS backup မဟုတ်ပါ" }
        require(root.optInt("version", 0) in 1..VERSION) { "Backup ဗားရှင်း မကိုက်ညီပါ" }

        val st = root.optJSONObject("settings")
        val settings = Restored(
            shopName = st?.optString("shopName")?.takeIf { it.isNotBlank() },
            footer = st?.optString("footer"),
            bigRate = st?.takeIf { it.has("bigRate") }?.getInt("bigRate"),
            smallRate = st?.takeIf { it.has("smallRate") }?.getInt("smallRate"),
            markerRate = st?.takeIf { it.has("markerRate") }?.getInt("markerRate")
        )
        return Parsed(
            settings = settings,
            tables = root.getJSONArray("tables").mapObjects { it.toTable() },
            products = root.getJSONArray("products").mapObjects { it.toProduct() },
            tableItems = root.getJSONArray("tableItems").mapObjects { it.toTableItem() },
            sales = root.getJSONArray("sales").mapObjects { it.toSale() },
            saleItems = root.getJSONArray("saleItems").mapObjects { it.toSaleItem() },
            waiters = root.optJSONArray("waiters")?.mapObjects { it.toWaiter() } ?: emptyList(),
            markerPeople = root.optJSONArray("markerPeople")?.mapObjects { it.toMarkerPerson() } ?: emptyList(),
            markerPays = root.optJSONArray("markerPays")?.mapObjects { it.toMarkerPay() } ?: emptyList(),
            markers = root.optJSONArray("markers")?.mapObjects { it.toMarker() } ?: emptyList(),
            staff = root.optJSONArray("staff")?.mapObjects { it.toStaff() }
        )
    }

    // ---- JSON helpers ---------------------------------------------------

    private fun <T> List<T>.toJsonArray(f: (T) -> JSONObject): JSONArray {
        val array = JSONArray()
        forEach { array.put(f(it)) }
        return array
    }

    private fun <T> JSONArray.mapObjects(f: (JSONObject) -> T): List<T> =
        List(length()) { f(getJSONObject(it)) }

    private fun JSONObject.longOrNull(key: String): Long? =
        if (has(key) && !isNull(key)) getLong(key) else null

    private fun BilliardTable.toJson() = JSONObject()
        .put("id", id).put("name", name).put("ratePerHour", ratePerHour)
        .put("isCounter", isCounter).put("startTime", startTime)
        .put("sortOrder", sortOrder).put("size", size).put("sessionRate", sessionRate)

    private fun JSONObject.toTable() = BilliardTable(
        id = getLong("id"),
        name = getString("name"),
        ratePerHour = getInt("ratePerHour"),
        isCounter = getBoolean("isCounter"),
        startTime = longOrNull("startTime"),
        sortOrder = optInt("sortOrder"),
        size = optString("size", TableSize.SMALL.name),
        sessionRate = optInt("sessionRate")
    )

    private fun Product.toJson() = JSONObject()
        .put("id", id).put("name", name).put("price", price).put("category", category)
        .put("trackStock", trackStock).put("stock", stock).put("active", active)

    private fun JSONObject.toProduct() = Product(
        id = getLong("id"),
        name = getString("name"),
        price = getInt("price"),
        category = optString("category"),
        trackStock = optBoolean("trackStock"),
        stock = optInt("stock"),
        active = optBoolean("active", true)
    )

    private fun TableItem.toJson() = JSONObject()
        .put("id", id).put("tableId", tableId).put("productId", productId)
        .put("name", name).put("price", price).put("qty", qty)

    private fun JSONObject.toTableItem() = TableItem(
        id = getLong("id"),
        tableId = getLong("tableId"),
        productId = getLong("productId"),
        name = getString("name"),
        price = getInt("price"),
        qty = getInt("qty")
    )

    private fun Sale.toJson() = JSONObject()
        .put("id", id).put("tableName", tableName).put("startTime", startTime)
        .put("endTime", endTime).put("minutes", minutes).put("playAmount", playAmount)
        .put("itemsAmount", itemsAmount).put("discount", discount).put("total", total)
        .put("createdAt", createdAt).put("staffName", staffName)
        .put("markerAmount", markerAmount).put("markerMinutes", markerMinutes)
        .put("waiterName", waiterName)

    private fun JSONObject.toSale() = Sale(
        id = getLong("id"),
        tableName = getString("tableName"),
        startTime = longOrNull("startTime"),
        endTime = getLong("endTime"),
        minutes = getInt("minutes"),
        playAmount = getInt("playAmount"),
        itemsAmount = getInt("itemsAmount"),
        discount = optInt("discount"),
        total = getInt("total"),
        createdAt = getLong("createdAt"),
        staffName = optString("staffName"),
        markerAmount = optInt("markerAmount"),
        markerMinutes = optInt("markerMinutes"),
        waiterName = optString("waiterName")
    )

    private fun MarkerStint.toJson() = JSONObject()
        .put("id", id).put("tableId", tableId).put("startTime", startTime)
        .put("endTime", endTime).put("rate", rate).put("markerName", markerName)

    private fun JSONObject.toMarker() = MarkerStint(
        id = getLong("id"),
        tableId = getLong("tableId"),
        startTime = getLong("startTime"),
        endTime = longOrNull("endTime"),
        rate = getInt("rate"),
        markerName = optString("markerName")
    )

    private fun MarkerPerson.toJson() = JSONObject()
        .put("id", id).put("name", name).put("active", active)

    private fun JSONObject.toMarkerPerson() =
        MarkerPerson(getLong("id"), getString("name"), optBoolean("active", true))

    private fun Waiter.toJson() = JSONObject()
        .put("id", id).put("name", name).put("active", active)

    private fun JSONObject.toWaiter() =
        Waiter(getLong("id"), getString("name"), optBoolean("active", true))

    private fun MarkerPay.toJson() = JSONObject()
        .put("id", id).put("saleId", saleId).put("markerName", markerName)
        .put("minutes", minutes).put("amount", amount).put("createdAt", createdAt)

    private fun JSONObject.toMarkerPay() = MarkerPay(
        id = getLong("id"),
        saleId = getLong("saleId"),
        markerName = getString("markerName"),
        minutes = getInt("minutes"),
        amount = getInt("amount"),
        createdAt = getLong("createdAt")
    )

    private fun Staff.toJson() = JSONObject()
        .put("id", id).put("name", name).put("role", role)
        .put("salt", salt).put("pinHash", pinHash).put("active", active)

    private fun JSONObject.toStaff() = Staff(
        id = getLong("id"),
        name = getString("name"),
        role = optString("role", Role.STAFF.name),
        salt = getString("salt"),
        pinHash = getString("pinHash"),
        active = optBoolean("active", true)
    )

    private fun SaleItem.toJson() = JSONObject()
        .put("id", id).put("saleId", saleId).put("name", name)
        .put("price", price).put("qty", qty)

    private fun JSONObject.toSaleItem() = SaleItem(
        id = getLong("id"),
        saleId = getLong("saleId"),
        name = getString("name"),
        price = getInt("price"),
        qty = getInt("qty")
    )
}

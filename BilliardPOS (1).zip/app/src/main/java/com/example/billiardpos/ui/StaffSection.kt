@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.billiardpos.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.billiardpos.data.Role
import com.example.billiardpos.data.Staff
import com.example.billiardpos.data.roleEnum
import com.example.billiardpos.util.Pin

/** Admin-only list of staff accounts inside Settings. */
@Composable
fun StaffSection(vm: PosViewModel) {
    val staff by vm.staffList.collectAsStateWithLifecycle()
    val me by vm.currentUser.collectAsStateWithLifecycle()
    var adding by remember { mutableStateOf(false) }
    var resetFor by remember { mutableStateOf<Staff?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        staff.forEach { person ->
            Card(Modifier.fillMaxWidth()) {
                Column {
                    ListItem(
                        headlineContent = {
                            Text(person.name + if (person.id == me?.id) "  (ကျွန်ုပ်)" else "")
                        },
                        supportingContent = {
                            Text(
                                person.roleEnum().label + if (person.active) "" else "  •  ပိတ်ထားသည်",
                                color = if (person.active) {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                } else {
                                    MaterialTheme.colorScheme.error
                                }
                            )
                        }
                    )
                    Row(Modifier.padding(horizontal = 8.dp)) {
                        TextButton(onClick = { resetFor = person }) { Text("PIN ပြောင်း") }
                        TextButton(onClick = { vm.setStaffActive(person.id, !person.active) }) {
                            Text(if (person.active) "ပိတ်မည်" else "ပြန်ဖွင့်မည်")
                        }
                    }
                }
            }
        }
        OutlinedButton(onClick = { adding = true }) { Text("ဝန်ထမ်းအသစ် ထည့်မည်") }
        Text(
            "Staff သည် ခုံဖွင့်၊ ပစ္စည်းထည့်၊ ငွေရှင်း၊ ဘောက်ချာထုတ်ရုံသာ လုပ်နိုင်ပါသည်။ ဈေးနှုန်း၊ ပစ္စည်းစာရင်း၊ လျှော့ငွေ၊ ပယ်ဖျက်ခြင်း၊ report၊ ဆက်တင်များသည် Admin သာ လုပ်နိုင်ပါသည်။ Admin PIN မေ့သွားမည်ကို စိုးလျှင် Admin နှစ်ယောက် ထားပါ။",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (adding) {
        AddStaffDialog(
            onSave = { name, role, pin ->
                vm.addStaff(name, role, pin)
                adding = false
            },
            onDismiss = { adding = false }
        )
    }
    resetFor?.let { person ->
        ResetPinDialog(
            name = person.name,
            onSave = { pin ->
                vm.resetPin(person.id, pin)
                resetFor = null
            },
            onDismiss = { resetFor = null }
        )
    }
}

@Composable
private fun AddStaffDialog(
    onSave: (name: String, role: Role, pin: String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(Role.STAFF) }
    var pin by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ဝန်ထမ်းအသစ်") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("အမည်") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                RoleChips(selected = role, onSelect = { role = it })
                PinField(
                    value = pin,
                    label = "PIN (${Pin.MIN_LENGTH}-${Pin.MAX_LENGTH} လုံး)",
                    onChange = { pin = it },
                    imeAction = ImeAction.Done,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name, role, pin) },
                enabled = name.isNotBlank() && Pin.isValid(pin)
            ) { Text("ထည့်မည်") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("မလုပ်တော့ပါ") } }
    )
}

@Composable
private fun ResetPinDialog(
    name: String,
    onSave: (pin: String) -> Unit,
    onDismiss: () -> Unit
) {
    var pin by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("$name — PIN အသစ်") },
        text = {
            PinField(
                value = pin,
                label = "PIN အသစ် (${Pin.MIN_LENGTH}-${Pin.MAX_LENGTH} လုံး)",
                onChange = { pin = it },
                imeAction = ImeAction.Done,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(onClick = { onSave(pin) }, enabled = Pin.isValid(pin)) { Text("ပြောင်းမည်") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("မလုပ်တော့ပါ") } }
    )
}

/** Editable list of names: add, rename, switch off / on. Used for markers and waiters. */
@Composable
private fun NameListSection(
    names: List<Triple<Long, String, Boolean>>,
    addLabel: String,
    hint: String,
    onAdd: (String) -> Unit,
    onRename: (Long, String) -> Unit,
    onActive: (Long, Boolean) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var renaming by remember { mutableStateOf<Triple<Long, String, Boolean>?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        names.forEach { entry ->
            val (id, label, active) = entry
            Card(Modifier.fillMaxWidth()) {
                ListItem(
                    headlineContent = { Text(label) },
                    supportingContent = { if (!active) Text("ပိတ်ထားသည်") },
                    trailingContent = {
                        Row {
                            TextButton(onClick = { renaming = entry }) { Text("နာမည်ပြင်") }
                            TextButton(onClick = { onActive(id, !active) }) {
                                Text(if (active) "ပိတ်မည်" else "ပြန်ဖွင့်မည်")
                            }
                        }
                    }
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text(addLabel) },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = { onAdd(name); name = "" },
                enabled = name.isNotBlank()
            ) { Text("ထည့်မည်") }
        }
        Text(
            hint,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    renaming?.let { entry ->
        var text by remember(entry.first) { mutableStateOf(entry.second) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("နာမည်ပြောင်းမည်") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = { onRename(entry.first, text); renaming = null },
                    enabled = text.isNotBlank()
                ) { Text("သိမ်းမည်") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("မလုပ်တော့ပါ") } }
        )
    }
}

/** Admin-only list of marker names (the people who can be assigned to tables). */
@Composable
fun MarkerPeopleSection(vm: PosViewModel) {
    val people by vm.markerPeople.collectAsStateWithLifecycle()
    NameListSection(
        names = people.map { Triple(it.id, it.name, it.active) },
        addLabel = "မာကာ အမည်",
        hint = "ခုံတွင် မာကာ ထည့်ရာ၌ ဤစာရင်းမှ ရွေးရပါမည်။ မာကာတစ်ယောက်ချင်းစီ လခ ကို report တွင် ကြည့်နိုင်သည်။ နာမည်ပြောင်းလျှင် ဘောက်ချာအဟောင်းများတွင် နာမည်အဟောင်းပင် ကျန်ပါမည်။",
        onAdd = { vm.addMarkerPerson(it) },
        onRename = { id, n -> vm.renameMarkerPerson(id, n) },
        onActive = { id, a -> vm.setMarkerPersonActive(id, a) }
    )
}

/** Admin-only list of waiters (စားပွဲထိုး) who hand over the bill and take the money. */
@Composable
fun WaiterSection(vm: PosViewModel) {
    val waiters by vm.waiters.collectAsStateWithLifecycle()
    NameListSection(
        names = waiters.map { Triple(it.id, it.name, it.active) },
        addLabel = "စားပွဲထိုး အမည်",
        hint = "ငွေရှင်းချိန်တွင် ဘေပေးပြီး ငွေယူသော စားပွဲထိုးကို ဤစာရင်းမှ ရွေးပါမည်။ ဘောက်ချာနှင့် report တွင် နာမည်ပါမည်။",
        onAdd = { vm.addWaiter(it) },
        onRename = { id, n -> vm.renameWaiter(id, n) },
        onActive = { id, a -> vm.setWaiterActive(id, a) }
    )
}

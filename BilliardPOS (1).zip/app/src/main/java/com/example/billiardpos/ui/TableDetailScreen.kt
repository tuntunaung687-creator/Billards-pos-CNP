@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.billiardpos.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.billiardpos.data.BilliardTable
import com.example.billiardpos.data.Product
import com.example.billiardpos.data.TableItem
import com.example.billiardpos.data.billingRate
import com.example.billiardpos.data.tableSize
import com.example.billiardpos.util.Billing
import com.example.billiardpos.util.Fmt

@Composable
fun TableDetailScreen(
    vm: PosViewModel,
    tableId: Long,
    onBack: () -> Unit
) {
    val tables by vm.tables.collectAsStateWithLifecycle()
    val allItems by vm.allItems.collectAsStateWithLifecycle()
    val products by vm.products.collectAsStateWithLifecycle()
    val allMarkers by vm.allMarkers.collectAsStateWithLifecycle()
    val markerPeople by vm.markerPeople.collectAsStateWithLifecycle()
    val waiters by vm.waiters.collectAsStateWithLifecycle()
    val lastWaiter by vm.lastWaiter.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val isAdmin by vm.isAdmin.collectAsStateWithLifecycle()

    var showPicker by remember { mutableStateOf(false) }
    var showCheckout by remember { mutableStateOf(false) }
    var showCancel by remember { mutableStateOf(false) }
    var qtyItem by remember { mutableStateOf<TableItem?>(null) }
    var showMove by remember { mutableStateOf(false) }

    val table = tables.find { it.id == tableId }
    if (table == null) {
        Column(Modifier.fillMaxSize()) {
            PosTopBar("ခုံ", onBack)
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("ခုံ မတွေ့ပါ")
            }
        }
        return
    }

    val tItems = allItems.filter { it.tableId == tableId }
    val start = table.startTime
    val running = !table.isCounter && start != null
    val minutes = if (running && start != null) Billing.minutes(start, now) else 0
    val play = if (running) Billing.playAmount(table.billingRate(), minutes) else 0
    val stints = allMarkers.filter { it.tableId == tableId }
    val markerFee = Billing.marker(stints, now).amount
    val itemsTotal = tItems.sumOf { it.price * it.qty }
    val canAdd = table.isCounter || start != null
    val hasBill = running || tItems.isNotEmpty() || stints.isNotEmpty()

    Column(Modifier.fillMaxSize()) {
        PosTopBar(
            title = table.name,
            onBack = onBack,
            actions = {
                if (hasBill) TextButton(
                    onClick = { vm.shareRunning(tableId) },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) { Text("ဘေပို့") }
                if (running) TextButton(
                    onClick = { showMove = true },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) { Text("ခုံပြောင်း") }
            }
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                TimeCard(
                    table = table,
                    start = start,
                    now = now,
                    minutes = minutes,
                    play = play,
                    onStart = { vm.startTable(table.id) }
                )
            }
            if (!table.isCounter) item {
                MarkerCard(
                    stints = stints,
                    people = markerPeople,
                    busyNames = allMarkers.filter { it.endTime == null }.map { it.markerName }.toSet(),
                    now = now,
                    rate = settings.markerRate,
                    enabled = running,
                    onAdd = { vm.addMarker(table.id, it) },
                    onRemove = { vm.removeMarker(it) },
                    onSwap = { old, name -> vm.swapMarker(old, name) }
                )
            }
            item {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "ပစ္စည်းများ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Button(onClick = { showPicker = true }, enabled = canAdd) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Text("ထည့်ရန်")
                    }
                }
            }
            if (!canAdd) {
                item {
                    Text(
                        "ပစ္စည်းထည့်ရန် ဆော့ချိန်ကို အရင် စတင်ပါ",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else if (tItems.isEmpty()) {
                item {
                    Text(
                        "ပစ္စည်း မရှိသေးပါ",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            items(tItems, key = { it.id }) { ti ->
                ItemRow(
                    item = ti,
                    onQtyClick = { qtyItem = ti },
                    onMinus = { vm.changeQty(ti, -1) },
                    onPlus = { vm.changeQty(ti, +1) }
                )
            }
        }

        Surface(tonalElevation = 3.dp, shadowElevation = 6.dp) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (!table.isCounter) SummaryLine("ခုံကြေး", Fmt.ks(play))
                if (markerFee > 0) SummaryLine("မာကာကြေး", Fmt.ks(markerFee))
                SummaryLine("အခြားရောင်းရငွေ", Fmt.ks(itemsTotal))
                SummaryLine("စုစုပေါင်း", Fmt.ks(play + markerFee + itemsTotal), bold = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (isAdmin) OutlinedButton(
                        onClick = { showCancel = true },
                        enabled = hasBill,
                        modifier = Modifier.weight(1f)
                    ) { Text("ပယ်ဖျက်မည်") }
                    Button(
                        onClick = { showCheckout = true },
                        enabled = hasBill,
                        modifier = Modifier.weight(2f)
                    ) { Text("ငွေရှင်းမည်") }
                }
            }
        }
    }

    if (showPicker) {
        ProductPicker(
            products = products,
            tItems = tItems,
            onAdd = { vm.addItem(tableId, it) },
            onDismiss = { showPicker = false }
        )
    }
    if (showMove) {
        val emptyIds = allItems.map { it.tableId }.toSet()
        MoveTableDialog(
            candidates = tables.filter {
                !it.isCounter && it.id != tableId && it.startTime == null && it.id !in emptyIds
            },
            onPick = { target ->
                showMove = false
                vm.moveTable(tableId, target.id) { onBack() }
            },
            onDismiss = { showMove = false }
        )
    }
    qtyItem?.let { item ->
        QtyDialog(
            item = item,
            onSet = { vm.setQty(item, it); qtyItem = null },
            onDismiss = { qtyItem = null }
        )
    }
    if (showCheckout) {
        CheckoutDialog(
            canDiscount = isAdmin,
            play = play,
            markerFee = markerFee,
            itemsTotal = itemsTotal,
            defaultPrint = settings.autoPrint,
            waiters = waiters.filter { it.active }.map { it.name },
            initialWaiter = lastWaiter,
            onConfirm = { discount, print, share, waiter ->
                showCheckout = false
                vm.checkout(tableId, discount, print, share, waiter) { onBack() }
            },
            onDismiss = { showCheckout = false }
        )
    }
    if (showCancel) {
        ConfirmDialog(
            title = "ပယ်ဖျက်မည်လား?",
            text = "လက်ရှိ စာရင်းကို ရောင်းအားမှတ်တမ်း မသိမ်းဘဲ ဖျက်ပစ်ပါမည်။",
            confirmLabel = "ပယ်ဖျက်မည်",
            onConfirm = {
                showCancel = false
                vm.cancelSession(tableId)
            },
            onDismiss = { showCancel = false }
        )
    }
}

@Composable
private fun TimeCard(
    table: BilliardTable,
    start: Long?,
    now: Long,
    minutes: Int,
    play: Int,
    onStart: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            when {
                table.isCounter -> {
                    Text(
                        "ကောင်တာ ရောင်းချမှု",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                start == null -> {
                    Text("ခုံလွတ်နေသည်", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${table.tableSize().label}  •  ${Fmt.ks(table.ratePerHour)} / နာရီ",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = onStart) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Text("ဆော့ချိန် စတင်မည်")
                    }
                }
                else -> {
                    Text(
                        Fmt.clock(now - start),
                        style = MaterialTheme.typography.displaySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "စတင်ချိန် ${Fmt.time(start)}  •  ${Fmt.hm(minutes)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "ခုံကြေး ${Fmt.ks(play)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun ItemRow(
    item: TableItem,
    onQtyClick: () -> Unit,
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(start = 12.dp, top = 4.dp, end = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(item.name, fontWeight = FontWeight.Medium)
                Text(
                    Fmt.ks(item.price),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onMinus) {
                Icon(Icons.Filled.Remove, contentDescription = "လျှော့ရန်")
            }
            Text(
                "${item.qty}",
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .width(40.dp)
                    .clickable(onClick = onQtyClick)
                    .padding(vertical = 8.dp)
            )
            IconButton(onClick = onPlus) {
                Icon(Icons.Filled.Add, contentDescription = "တိုးရန်")
            }
            Text(
                Fmt.ks(item.price * item.qty),
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.End,
                modifier = Modifier
                    .width(92.dp)
                    .padding(end = 8.dp)
            )
        }
    }
}

@Composable
private fun ProductPicker(
    products: List<Product>,
    tItems: List<TableItem>,
    onAdd: (Product) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ပစ္စည်း ရွေးရန်") },
        text = {
            if (products.isEmpty()) {
                Text("ပစ္စည်း မရှိသေးပါ။ \"ပစ္စည်းများ\" tab တွင် အရင်ထည့်ပါ။")
            } else {
                var query by remember { mutableStateOf("") }
                val shown = products.filter {
                    query.isBlank() || it.name.contains(query.trim(), ignoreCase = true) ||
                        it.category.contains(query.trim(), ignoreCase = true)
                }
                Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("ရှာရန် (${products.size} မျိုး)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                    items(shown, key = { it.id }) { product ->
                        val inCart = tItems.firstOrNull { it.productId == product.id }?.qty ?: 0
                        val outOfStock = product.trackStock && inCart >= product.stock
                        ListItem(
                            headlineContent = { Text(product.name) },
                            supportingContent = {
                                val stock = if (product.trackStock) "  •  လက်ကျန် ${product.stock}" else ""
                                Text(Fmt.ks(product.price) + stock)
                            },
                            trailingContent = {
                                if (inCart > 0) {
                                    Text("x$inCart", fontWeight = FontWeight.Bold)
                                }
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable(enabled = !outOfStock) { onAdd(product) }
                        )
                        HorizontalDivider()
                    }
                }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("ပြီးပါပြီ") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CheckoutDialog(
    canDiscount: Boolean,
    play: Int,
    markerFee: Int,
    itemsTotal: Int,
    defaultPrint: Boolean,
    waiters: List<String>,
    initialWaiter: String,
    onConfirm: (discount: Int, print: Boolean, share: Boolean, waiter: String) -> Unit,
    onDismiss: () -> Unit
) {
    var discountText by remember { mutableStateOf("") }
    var print by remember { mutableStateOf(defaultPrint) }
    var share by remember { mutableStateOf(false) }
    var waiter by remember { mutableStateOf(initialWaiter.takeIf { it in waiters } ?: "") }
    val discount = discountText.toIntOrNull() ?: 0
    val gross = play + markerFee + itemsTotal
    val total = (gross - discount).coerceAtLeast(0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ငွေရှင်းမည်") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (play > 0) SummaryLine("ခုံကြေး", Fmt.ks(play))
                if (markerFee > 0) SummaryLine("မာကာကြေး", Fmt.ks(markerFee))
                SummaryLine("အခြားရောင်းရငွေ", Fmt.ks(itemsTotal))
                if (waiters.isNotEmpty()) {
                    Text("စားပွဲထိုး (ဘေပေး ငွေယူသူ)", style = MaterialTheme.typography.labelLarge)
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        waiters.forEach { w ->
                            FilterChip(
                                selected = waiter == w,
                                onClick = { waiter = w },
                                label = { Text(w) }
                            )
                        }
                    }
                }
                if (canDiscount) NumberField(
                    value = discountText,
                    label = "လျှော့ငွေ (Ks)",
                    onChange = { discountText = it },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = print, onCheckedChange = { print = it })
                    Spacer(Modifier.width(4.dp))
                    Text("ဘောက်ချာ ပရင့်ထုတ်မည်")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = share, onCheckedChange = { share = it })
                    Spacer(Modifier.width(4.dp))
                    Text("ဖုန်းသို့ ဘေပို့မည် (Viber/Telegram)")
                }
                HorizontalDivider()
                SummaryLine("ပေးရန်", Fmt.ks(total), bold = true)
            }
        },
        confirmButton = {
            Button(
                enabled = waiters.isEmpty() || waiter.isNotBlank(),
                onClick = { onConfirm(discount.coerceAtMost(gross), print, share, waiter) }
            ) {
                Text("အတည်ပြုမည်")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("မလုပ်တော့ပါ") } }
    )
}

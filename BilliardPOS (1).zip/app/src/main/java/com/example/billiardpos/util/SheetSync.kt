package com.example.billiardpos.util

import com.example.billiardpos.data.MarkerPay
import com.example.billiardpos.data.Sale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Uploads closed bills to the owner's Google Sheet through a small Google Apps Script web app,
 * so the owner can watch sales from any phone. No account or SDK is needed inside the app.
 */
object SheetSync {
    private fun month(ms: Long) = SimpleDateFormat("yyyy-MM", Locale.US).format(Date(ms))
    private fun stamp(ms: Long) = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(ms))

    /** One row of the owner's live table board. */
    data class LiveRow(
        val name: String,
        val size: String,
        val running: Boolean,
        val startText: String,
        val minutes: Int,
        val play: Int,
        val markers: Int,
        val markerFee: Int,
        val items: Int,
        val total: Int
    )

    /** Sends the current state of every table; the script rewrites the `Live` sheet. */
    suspend fun pushLive(url: String, token: String, shop: String, rows: List<LiveRow>): Result<Unit> =
        post(
            url,
            JSONObject()
                .put("token", token)
                .put("shop", shop)
                .put("updated", stamp(System.currentTimeMillis()))
                .put(
                    "live",
                    JSONArray().apply {
                        rows.forEach {
                            put(
                                JSONArray().put(it.name).put(it.size)
                                    .put(if (it.running) "ဆော့နေသည်" else "လွတ်")
                                    .put(it.startText).put(it.minutes).put(it.play)
                                    .put(it.markers).put(it.markerFee).put(it.items).put(it.total)
                            )
                        }
                    }
                ).toString()
        )

    /** Returns Result.success when the script answered {"ok":true}. */
    suspend fun push(
        url: String,
        token: String,
        shop: String,
        sales: List<Sale>,
        pays: List<MarkerPay>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val bills = JSONArray()
            sales.forEach { s ->
                bills.put(
                    JSONArray()
                        .put(s.id).put(month(s.createdAt)).put(stamp(s.createdAt))
                        .put(s.tableName).put(s.minutes).put(s.playAmount).put(s.markerAmount)
                        .put(s.itemsAmount).put(s.discount).put(s.total).put(s.staffName).put(s.waiterName)
                )
            }
            val markerRows = JSONArray()
            pays.forEach { p ->
                markerRows.put(
                    JSONArray()
                        .put(p.saleId).put(month(p.createdAt)).put(p.markerName)
                        .put(p.minutes).put(p.amount).put(stamp(p.createdAt))
                )
            }
            post(
                url,
                JSONObject()
                    .put("token", token)
                    .put("shop", shop)
                    .put("bills", bills)
                    .put("markerPay", markerRows)
                    .toString()
            ).getOrThrow()
        }
    }

    private suspend fun post(url: String, body: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 30_000
                doOutput = true
                instanceFollowRedirects = true
                setRequestProperty("Content-Type", "text/plain; charset=utf-8")
            }
            try {
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) error("HTTP $code")
                val ok = runCatching { JSONObject(text).optBoolean("ok") }.getOrDefault(false)
                if (!ok) {
                    val reason = runCatching { JSONObject(text).optString("error") }.getOrDefault("")
                    error(
                        when {
                            reason == "token" -> "Token မကိုက်ပါ"
                            reason.isNotBlank() -> "Script အမှား: " + reason.take(120)
                            else -> "Script အဖြေ မမှန်ပါ (Deploy ကို New version ပြန်လုပ်ပါ): " + text.take(60)
                        }
                    )
                }
            } finally {
                conn.disconnect()
            }
        }
    }
}

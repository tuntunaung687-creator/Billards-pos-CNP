package com.example.billiardpos.data

import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/**
 * Whole-shop backup as one JSON file: tables, products, running bills, sales history and
 * the shop/rate settings. Restoring replaces everything currently in the app.
 */
object Backup {
    private const val APP = "BilliardPOS"
    private const val VERSION = 1

    data class Restored(
        val shopName: String?,
        val footer: String?,
        val bigRate: Int?,
        val smallRate: Int?
    )

    private class Parsed(
        val settings: Restored,
        val tables: List<BilliardTable>,
        val products: List<Product>,
        val tableItems: List<TableItem>,
        val sales: List<Sale>,
        val saleItems: List<SaleItem>
    )

    suspend fun export(db: AppDatabase, s: AppSettings, now: Long): String = db.withTransaction {
        JSONObject()
            .put("app", APP)
            .put("version", VERSION)
            .put("exportedAt", now)
            .put(
                "settings",
                JSONObject()
                    .put("shopName", s.shopName)
                    .put("footer", s.footer)
                    .put("bigRate", s.bigRate)
                    .put("smallRate", s.smallRate)
            )
            .put("tables", db.tableDao().getAll().toJsonArray { it.toJson() })
            .put("products", db.productDao().getAll().toJsonArray { it.toJson() })
            .put("tableItems", db.itemDao().getAll().toJsonArray { it.toJson() })
            .put("sales", db.saleDao().getAllSales().toJsonArray { it.toJson() })
            .put("saleItems", db.saleDao().getAllSaleItems().toJsonArray { it.toJson() })
            .toString(2)
    }

    /** Replaces all data with the backup. Throws [IllegalArgumentException] for a bad file. */
    suspend fun restore(db: AppDatabase, text: String): Restored {
        // Parse everything first: a bad file must never touch the current data.
        val parsed = try {
            parse(text)
        } catch (e: JSONException) {
            throw IllegalArgumentException("Backup ဖိုင်ပုံစံ မမှန်ပါ")
        }
        db.withTransaction {
            db.itemDao().deleteAll()
            db.saleDao().deleteAllSaleItems()
            db.saleDao().deleteAllSales()
            db.tableDao().deleteAll()
            db.productDao().deleteAll()

            db.tableDao().insertAll(parsed.tables)
            db.productDao().insertAll(parsed.products)
            db.itemDao().insertAll(parsed.tableItems)
            db.saleDao().insertSales(parsed.sales)
            db.saleDao().insertItems(parsed.saleItems)
        }
        return parsed.settings
    }

    private fun parse(text: String): Parsed {
        val root = JSONObject(text)
        require(root.optString("app") == APP) { "ဤဖိုင်သည် Billiard POS backup မဟုတ်ပါ" }
        require(root.optInt("version", 0) in 1..VERSION) { "Backup ဗားရှင်း မကိုက်ညီပါ" }

        val st = root.optJSONObject("settings")
        val settings = Restored(
            shopName = st?.optString("shopName")?.takeIf { it.isNotBlank() },
            footer = st?.optString("footer"),
            bigRate = st?.takeIf { it.has("bigRate") }?.getInt("bigRate"),
            smallRate = st?.takeIf { it.has("smallRate") }?.getInt("smallRate")
        )
        return Parsed(
            settings = settings,
            tables = root.getJSONArray("tables").mapObjects { it.toTable() },
            products = root.getJSONArray("products").mapObjects { it.toProduct() },
            tableItems = root.getJSONArray("tableItems").mapObjects { it.toTableItem() },
            sales = root.getJSONArray("sales").mapObjects { it.toSale() },
            saleItems = root.getJSONArray("saleItems").mapObjects { it.toSaleItem() }
        )
    }

    // ---- JSON helpers ---------------------------------------------------

    private fun <T> List<T>.toJsonArray(f: (T) -> JSONObject): JSONArray {
        val array = JSONArray()
        forEach { array.put(f(it)) }
        return array
    }

    private fun <T> JSONArray.mapObjects(f: (JSONObject) -> T): List<T> =
        List(length()) { f(getJSONObject(it)) }

    private fun JSONObject.longOrNull(key: String): Long? =
        if (has(key) && !isNull(key)) getLong(key) else null

    private fun BilliardTable.toJson() = JSONObject()
        .put("id", id).put("name", name).put("ratePerHour", ratePerHour)
        .put("isCounter", isCounter).put("startTime", startTime)
        .put("sortOrder", sortOrder).put("size", size).put("sessionRate", sessionRate)

    private fun JSONObject.toTable() = BilliardTable(
        id = getLong("id"),
        name = getString("name"),
        ratePerHour = getInt("ratePerHour"),
        isCounter = getBoolean("isCounter"),
        startTime = longOrNull("startTime"),
        sortOrder = optInt("sortOrder"),
        size = optString("size", TableSize.SMALL.name),
        sessionRate = optInt("sessionRate")
    )

    private fun Product.toJson() = JSONObject()
        .put("id", id).put("name", name).put("price", price).put("category", category)
        .put("trackStock", trackStock).put("stock", stock).put("active", active)

    private fun JSONObject.toProduct() = Product(
        id = getLong("id"),
        name = getString("name"),
        price = getInt("price"),
        category = optString("category"),
        trackStock = optBoolean("trackStock"),
        stock = optInt("stock"),
        active = optBoolean("active", true)
    )

    private fun TableItem.toJson() = JSONObject()
        .put("id", id).put("tableId", tableId).put("productId", productId)
        .put("name", name).put("price", price).put("qty", qty)

    private fun JSONObject.toTableItem() = TableItem(
        id = getLong("id"),
        tableId = getLong("tableId"),
        productId = getLong("productId"),
        name = getString("name"),
        price = getInt("price"),
        qty = getInt("qty")
    )

    private fun Sale.toJson() = JSONObject()
        .put("id", id).put("tableName", tableName).put("startTime", startTime)
        .put("endTime", endTime).put("minutes", minutes).put("playAmount", playAmount)
        .put("itemsAmount", itemsAmount).put("discount", discount).put("total", total)
        .put("createdAt", createdAt)

    private fun JSONObject.toSale() = Sale(
        id = getLong("id"),
        tableName = getString("tableName"),
        startTime = longOrNull("startTime"),
        endTime = getLong("endTime"),
        minutes = getInt("minutes"),
        playAmount = getInt("playAmount"),
        itemsAmount = getInt("itemsAmount"),
        discount = optInt("discount"),
        total = getInt("total"),
        createdAt = getLong("createdAt")
    )

    private fun SaleItem.toJson() = JSONObject()
        .put("id", id).put("saleId", saleId).put("name", name)
        .put("price", price).put("qty", qty)

    private fun JSONObject.toSaleItem() = SaleItem(
        id = getLong("id"),
        saleId = getLong("saleId"),
        name = getString("name"),
        price = getInt("price"),
        qty = getInt("qty")
    )
}

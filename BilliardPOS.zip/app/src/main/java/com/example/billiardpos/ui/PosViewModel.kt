package com.example.billiardpos.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.billiardpos.data.AppDatabase
import com.example.billiardpos.data.AppSettings
import com.example.billiardpos.data.BilliardTable
import com.example.billiardpos.data.PeriodSummary
import com.example.billiardpos.data.PosRepository
import com.example.billiardpos.data.Product
import com.example.billiardpos.data.Sale
import com.example.billiardpos.data.SaleItem
import com.example.billiardpos.data.SettingsStore
import com.example.billiardpos.data.TableItem
import com.example.billiardpos.data.TableSize
import com.example.billiardpos.data.TopProduct
import com.example.billiardpos.print.BluetoothPrinter
import com.example.billiardpos.print.EscPos
import com.example.billiardpos.print.PrinterDevice
import com.example.billiardpos.print.Receipt
import com.example.billiardpos.print.ReceiptRenderer
import com.example.billiardpos.util.Billing
import com.example.billiardpos.util.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.TimeZone

/** A time window (epoch millis, inclusive) shown in the bill list. */
data class RangeSel(val label: String, val from: Long, val to: Long)

enum class ReportRange(val label: String) {
    TODAY("ယနေ့"),
    WEEK("၇ ရက်"),
    MONTH("ဤလ"),
    YEAR("ဤနှစ်");

    fun toSel(): RangeSel {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val end = cal.timeInMillis + 24L * 60 * 60 * 1000 - 1
        when (this) {
            TODAY -> Unit
            WEEK -> cal.add(Calendar.DAY_OF_YEAR, -6)
            MONTH -> cal.set(Calendar.DAY_OF_MONTH, 1)
            YEAR -> cal.set(Calendar.DAY_OF_YEAR, 1)
        }
        return RangeSel(label, cal.timeInMillis, end)
    }
}

private fun monthBounds(year: Int, month0: Int): Pair<Long, Long> {
    val cal = Calendar.getInstance().apply { clear(); set(year, month0, 1) }
    val from = cal.timeInMillis
    cal.add(Calendar.MONTH, 1)
    return from to cal.timeInMillis - 1
}

private fun yearBounds(year: Int): Pair<Long, Long> {
    val cal = Calendar.getInstance().apply { clear(); set(year, Calendar.JANUARY, 1) }
    val from = cal.timeInMillis
    cal.add(Calendar.YEAR, 1)
    return from to cal.timeInMillis - 1
}

@OptIn(ExperimentalCoroutinesApi::class)
class PosViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = PosRepository(AppDatabase.get(app))
    private val settingsStore = SettingsStore(app)
    val printer = BluetoothPrinter(app)

    private val whileSubscribed = SharingStarted.WhileSubscribed(5_000)

    val tables: StateFlow<List<BilliardTable>> =
        repo.observeTables().stateIn(viewModelScope, whileSubscribed, emptyList())
    val allItems: StateFlow<List<TableItem>> =
        repo.observeAllItems().stateIn(viewModelScope, whileSubscribed, emptyList())
    val products: StateFlow<List<Product>> =
        repo.observeProducts().stateIn(viewModelScope, whileSubscribed, emptyList())
    val settings: StateFlow<AppSettings> = settingsStore.state

    /** Ticks every second so running timers redraw. */
    val now: StateFlow<Long> = flow {
        while (true) {
            emit(System.currentTimeMillis())
            delay(1_000)
        }
    }.stateIn(viewModelScope, whileSubscribed, System.currentTimeMillis())

    // ---- Reports --------------------------------------------------------

    /** Window used by the bill list (and the top-products card). */
    val billRange = MutableStateFlow(ReportRange.TODAY.toSel())

    /** Year shown by the monthly summary. */
    val summaryYear = MutableStateFlow(Calendar.getInstance().get(Calendar.YEAR))

    private fun tzOffset(): Long = TimeZone.getDefault().getOffset(System.currentTimeMillis()).toLong()

    val sales: StateFlow<List<Sale>> = billRange.flatMapLatest { r ->
        repo.observeSales(r.from, r.to)
    }.stateIn(viewModelScope, whileSubscribed, emptyList())

    val topProducts: StateFlow<List<TopProduct>> = billRange.flatMapLatest { r ->
        repo.observeTopProducts(r.from, r.to)
    }.stateIn(viewModelScope, whileSubscribed, emptyList())

    /** လချုပ် — one row per month of [summaryYear] (period = "yyyy-MM"). */
    val monthly: StateFlow<List<PeriodSummary>> = summaryYear.flatMapLatest { year ->
        val (from, to) = yearBounds(year)
        repo.observeSummary("%Y-%m", tzOffset(), from, to)
    }.stateIn(viewModelScope, whileSubscribed, emptyList())

    /** နှစ်ချုပ် — one row per year (period = "yyyy"). */
    val yearly: StateFlow<List<PeriodSummary>> =
        repo.observeSummary("%Y", tzOffset(), 0L, Long.MAX_VALUE)
            .stateIn(viewModelScope, whileSubscribed, emptyList())

    fun selectRange(range: ReportRange) {
        billRange.value = range.toSel()
    }

    fun selectMonth(year: Int, month0: Int) {
        val (from, to) = monthBounds(year, month0)
        billRange.value = RangeSel("${Fmt.monthName(month0)} $year", from, to)
    }

    fun selectYear(year: Int) {
        val (from, to) = yearBounds(year)
        billRange.value = RangeSel("$year", from, to)
    }

    // ---- Messages -------------------------------------------------------

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        viewModelScope.launch {
            val s = settings.value
            repo.seedIfEmpty(
                counterName = "ကောင်တာ",
                tablePrefix = "ခုံ",
                bigRate = s.bigRate,
                smallRate = s.smallRate
            )
        }
    }

    fun toast(message: String) {
        _messages.tryEmit(message)
    }

    // ---- Tables ---------------------------------------------------------

    fun addTable(name: String, size: TableSize) {
        viewModelScope.launch { repo.addTable(name, size, settings.value.rateFor(size)) }
    }

    fun updateTable(table: BilliardTable, name: String, size: TableSize) {
        viewModelScope.launch {
            val rate = if (table.isCounter) table.ratePerHour else settings.value.rateFor(size)
            val newSize = if (table.isCounter) table.size else size.name
            repo.updateTable(table.copy(name = name, size = newSize, ratePerHour = rate))
        }
    }

    fun deleteTable(table: BilliardTable) {
        viewModelScope.launch {
            if (!repo.deleteTable(table)) {
                toast("အသုံးပြုနေသော ခုံကို ဖျက်၍မရပါ")
            }
        }
    }

    fun startTable(id: Long) {
        viewModelScope.launch { repo.startTable(id, System.currentTimeMillis()) }
    }

    /** Sets the hourly rate of the 12 ft and 10 ft tables. */
    fun setRates(big: Int, small: Int) {
        settingsStore.update { it.copy(bigRate = big, smallRate = small) }
        viewModelScope.launch {
            repo.applyRate(TableSize.BIG, big)
            repo.applyRate(TableSize.SMALL, small)
            toast("ဈေးနှုန်း ပြောင်းပြီးပါပြီ (ဆော့နေသော ခုံများ မူလဈေးအတိုင်း ဆက်တွက်ပါမည်)")
        }
    }

    // ---- Running bill ---------------------------------------------------

    fun addItem(tableId: Long, product: Product) {
        viewModelScope.launch {
            if (!repo.addItem(tableId, product)) toast("လက်ကျန် မလုံလောက်ပါ")
        }
    }

    fun changeQty(item: TableItem, delta: Int) {
        viewModelScope.launch {
            if (!repo.changeQty(item, delta)) toast("လက်ကျန် မလုံလောက်ပါ")
        }
    }

    fun cancelSession(tableId: Long) {
        viewModelScope.launch { repo.cancelSession(tableId) }
    }

    fun checkout(tableId: Long, discount: Int, print: Boolean, onDone: () -> Unit) {
        viewModelScope.launch {
            val saleId = repo.checkout(tableId, discount, System.currentTimeMillis())
            onDone()
            toast("ငွေရှင်းပြီးပါပြီ")
            if (print) printSale(saleId)
        }
    }

    // ---- Products -------------------------------------------------------

    fun saveProduct(product: Product) {
        viewModelScope.launch { repo.saveProduct(product) }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch { repo.saveProduct(product.copy(active = false)) }
    }

    // ---- Bill slips -----------------------------------------------------

    suspend fun getSaleItems(saleId: Long): List<SaleItem> = repo.getSaleItems(saleId)

    // ---- Backup / restore / export --------------------------------------

    private suspend fun writeText(uri: Uri, text: String) = withContext(Dispatchers.IO) {
        val out = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
            ?: error("ဖိုင်ဖွင့်မရပါ")
        out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
    }

    /** Saves any text (CSV) to a file the user picked. */
    fun saveText(uri: Uri, text: String) {
        viewModelScope.launch {
            runCatching { writeText(uri, text) }
                .onSuccess { toast("ဖိုင် သိမ်းပြီးပါပြီ") }
                .onFailure { toast("ဖိုင်သိမ်း၍မရပါ: ${it.message ?: "မသိသော အမှား"}") }
        }
    }

    fun backupTo(uri: Uri) {
        viewModelScope.launch {
            runCatching {
                writeText(uri, repo.exportBackup(settings.value, System.currentTimeMillis()))
            }
                .onSuccess { toast("Backup သိမ်းပြီးပါပြီ") }
                .onFailure { toast("Backup မအောင်မြင်ပါ: ${it.message ?: "မသိသော အမှား"}") }
        }
    }

    fun restoreFrom(uri: Uri) {
        viewModelScope.launch {
            runCatching {
                val text = withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openInputStream(uri)
                        ?.use { it.readBytes().toString(Charsets.UTF_8) }
                        ?: error("ဖိုင်ဖွင့်မရပါ")
                }
                repo.importBackup(text)
            }
                .onSuccess { r ->
                    settingsStore.update {
                        it.copy(
                            shopName = r.shopName ?: it.shopName,
                            footer = r.footer ?: it.footer,
                            bigRate = r.bigRate ?: it.bigRate,
                            smallRate = r.smallRate ?: it.smallRate
                        )
                    }
                    toast("Backup မှ ပြန်ယူပြီးပါပြီ")
                }
                .onFailure { toast("ပြန်ယူ၍မရပါ: ${it.message ?: "မသိသော အမှား"}") }
        }
    }

    // ---- Settings & printing -------------------------------------------

    fun updateSettings(transform: (AppSettings) -> AppSettings) = settingsStore.update(transform)

    fun selectPrinter(device: PrinterDevice) {
        settingsStore.update { it.copy(printerAddress = device.address, printerName = device.name) }
    }

    fun printSale(saleId: Long) {
        viewModelScope.launch {
            val sale = repo.getSale(saleId) ?: return@launch
            val items = repo.getSaleItems(saleId)
            sendToPrinter(Receipt(settings.value.shopName, settings.value.footer, sale, items))
        }
    }

    fun testPrint() {
        viewModelScope.launch {
            val end = System.currentTimeMillis()
            val start = end - 75 * 60_000L
            val play = Billing.playAmount(settings.value.bigRate, 75)
            val items = listOf(
                SaleItem(saleId = 0, name = "ရေသန့်", price = 500, qty = 2),
                SaleItem(saleId = 0, name = "ကော်ဖီ", price = 1_000, qty = 1)
            )
            val itemsAmount = items.sumOf { it.price * it.qty }
            val sale = Sale(
                id = 0,
                tableName = "ခုံ ၁",
                startTime = start,
                endTime = end,
                minutes = 75,
                playAmount = play,
                itemsAmount = itemsAmount,
                discount = 0,
                total = play + itemsAmount,
                createdAt = end
            )
            sendToPrinter(Receipt(settings.value.shopName, settings.value.footer, sale, items))
        }
    }

    private suspend fun sendToPrinter(receipt: Receipt) {
        val s = settings.value
        if (s.printerAddress.isBlank()) {
            toast("ပရင်တာ မရွေးရသေးပါ — ဆက်တင်တွင် ရွေးပါ")
            return
        }
        val bytes = withContext(Dispatchers.Default) {
            val bitmap = ReceiptRenderer.render(receipt, if (s.paper80) 576 else 384)
            EscPos.build(bitmap).also { bitmap.recycle() }
        }
        printer.print(s.printerAddress, bytes)
            .onSuccess { toast("ဘောက်ချာ ပရင့်ထုတ်ပြီးပါပြီ") }
            .onFailure { toast("ပရင့်ထုတ်မရပါ: ${it.message ?: "မသိသော အမှား"}") }
    }
}

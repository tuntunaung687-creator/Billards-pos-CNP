package com.example.billiardpos.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * A small top-down picture of a billiard table: wooden frame, green cloth, six pockets.
 * When [active] the cloth is bright and balls are racked; when idle it is dim and empty.
 * The 12 ft table is drawn longer than the 10 ft one.
 */
@Composable
fun BilliardTableArt(active: Boolean, big: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(64.dp)) {
        val fullW = size.width
        val h = size.height
        val w = if (big) fullW else fullW * 0.86f
        val left = (fullW - w) / 2f
        val wood = if (active) Color(0xFF7A4A24) else Color(0xFF8C7B6B)
        val cloth = if (active) Color(0xFF1E9150) else Color(0xFF5E8C70)
        val pocket = Color(0xFF1B1B1B)

        drawRoundRect(wood, Offset(left, 0f), Size(w, h), CornerRadius(14f, 14f))
        val rim = h * 0.14f
        drawRoundRect(
            cloth,
            Offset(left + rim, rim),
            Size(w - rim * 2, h - rim * 2),
            CornerRadius(8f, 8f)
        )

        // Baulk line and spot.
        val lineX = left + w * 0.27f
        drawLine(Color(0x55FFFFFF), Offset(lineX, rim), Offset(lineX, h - rim), strokeWidth = 2f)

        // Six pockets: four corners and the middle of both long sides.
        val r = h * 0.11f
        val xs = listOf(left + rim * 0.6f, left + w / 2f, left + w - rim * 0.6f)
        val ys = listOf(rim * 0.6f, h - rim * 0.6f)
        xs.forEach { x -> ys.forEach { y -> drawCircle(pocket, r, Offset(x, y)) } }

        if (active) {
            val br = h * 0.075f
            // Cue ball.
            drawCircle(Color.White, br, Offset(left + w * 0.18f, h / 2f))
            // Racked triangle of balls.
            val colors = listOf(
                Color(0xFFE53935), Color(0xFFFDD835), Color(0xFF1E88E5),
                Color(0xFF8E24AA), Color(0xFFFB8C00), Color(0xFF212121)
            )
            var i = 0
            val startX = left + w * 0.66f
            for (col in 0..2) {
                for (row in 0..col) {
                    val x = startX + col * br * 1.8f
                    val y = h / 2f + (row - col / 2f) * br * 2.1f
                    drawCircle(colors[i % colors.size], br, Offset(x, y))
                    i++
                }
            }
        }
    }
}

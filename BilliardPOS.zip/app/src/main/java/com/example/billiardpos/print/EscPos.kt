package com.example.billiardpos.print

import android.graphics.Bitmap
import android.graphics.Color
import java.io.ByteArrayOutputStream

/** Minimal ESC/POS encoder: prints a bitmap using GS v 0 raster commands. */
object EscPos {
    /** Rows per GS v 0 command; smaller bands are more tolerant on cheap printers. */
    private const val BAND_ROWS = 128

    fun build(bitmap: Bitmap, cut: Boolean = true): ByteArray {
        val out = ByteArrayOutputStream()
        // ESC @ : initialise printer
        out.write(byteArrayOf(0x1B, 0x40))

        val w = bitmap.width
        val h = bitmap.height
        val widthBytes = (w + 7) / 8
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        var row = 0
        while (row < h) {
            val band = minOf(BAND_ROWS, h - row)
            // GS v 0 m xL xH yL yH
            out.write(
                byteArrayOf(
                    0x1D, 0x76, 0x30, 0x00,
                    (widthBytes and 0xFF).toByte(), ((widthBytes shr 8) and 0xFF).toByte(),
                    (band and 0xFF).toByte(), ((band shr 8) and 0xFF).toByte()
                )
            )
            val data = ByteArray(widthBytes * band)
            for (r in 0 until band) {
                for (x in 0 until w) {
                    val px = pixels[(row + r) * w + x]
                    val lum = (Color.red(px) * 299 + Color.green(px) * 587 + Color.blue(px) * 114) / 1000
                    if (lum < 140) {
                        val index = r * widthBytes + x / 8
                        data[index] = (data[index].toInt() or (0x80 shr (x % 8))).toByte()
                    }
                }
            }
            out.write(data)
            row += band
        }

        // ESC d 4 : feed 4 lines
        out.write(byteArrayOf(0x1B, 0x64, 0x04))
        if (cut) {
            // GS V 66 0 : feed and partial cut (ignored by printers without a cutter)
            out.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00))
        }
        return out.toByteArray()
    }
}

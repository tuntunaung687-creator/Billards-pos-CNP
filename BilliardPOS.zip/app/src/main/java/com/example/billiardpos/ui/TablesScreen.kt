@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.billiardpos.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.billiardpos.data.BilliardTable
import com.example.billiardpos.data.MarkerStint
import com.example.billiardpos.data.TableItem
import com.example.billiardpos.data.TableSize
import com.example.billiardpos.data.billingRate
import com.example.billiardpos.data.tableSize
import com.example.billiardpos.util.Billing
import com.example.billiardpos.util.Fmt

@Composable
fun TablesScreen(
    vm: PosViewModel,
    onOpen: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val tables by vm.tables.collectAsStateWithLifecycle()
    val allItems by vm.allItems.collectAsStateWithLifecycle()
    val allMarkers by vm.allMarkers.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val isAdmin by vm.isAdmin.collectAsStateWithLifecycle()
    val user by vm.currentUser.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<BilliardTable?>(null) }
    var adding by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize()) {
        PosTopBar(
            title = "ဘီလိယက်ခုံများ",
            actions = {
                Text(
                    user?.name.orEmpty(),
                    color = MaterialTheme.colorScheme.onPrimary,
                    style = MaterialTheme.typography.labelLarge
                )
                IconButton(onClick = { vm.logout() }) {
                    Icon(Icons.Filled.Lock, contentDescription = "ပိတ်မည် (Lock)")
                }
            }
        )
        Box(Modifier.fillMaxSize()) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(160.dp),
                contentPadding = PaddingValues(12.dp, 12.dp, 12.dp, 88.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(tables, key = { it.id }) { table ->
                    TableCard(
                        table = table,
                        tableItems = allItems.filter { it.tableId == table.id },
                        markers = allMarkers.filter { it.tableId == table.id },
                        now = now,
                        onClick = { onOpen(table.id) },
                        onEdit = { editing = table },
                        canEdit = isAdmin
                    )
                }
            }
            if (isAdmin) FloatingActionButton(
                onClick = { adding = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "ခုံထည့်ရန်")
            }
        }
    }

    if (adding) {
        TableDialog(
            initial = null,
            bigRate = settings.bigRate,
            smallRate = settings.smallRate,
            onSave = { name, size ->
                vm.addTable(name, size)
                adding = false
            },
            onDelete = null,
            onDismiss = { adding = false }
        )
    }
    editing?.let { table ->
        TableDialog(
            initial = table,
            bigRate = settings.bigRate,
            smallRate = settings.smallRate,
            onSave = { name, size ->
                vm.updateTable(table, name, size)
                editing = null
            },
            onDelete = if (table.isCounter) null else {
                {
                    vm.deleteTable(table)
                    editing = null
                }
            },
            onDismiss = { editing = null }
        )
    }
}

@Composable
private fun TableCard(
    table: BilliardTable,
    tableItems: List<TableItem>,
    markers: List<MarkerStint>,
    now: Long,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    canEdit: Boolean
) {
    val start = table.startTime
    val active = if (table.isCounter) tableItems.isNotEmpty() else start != null
    val itemsAmount = tableItems.sumOf { it.price * it.qty }
    val play = if (!table.isCounter && start != null) {
        Billing.playAmount(table.billingRate(), Billing.minutes(start, now))
    } else 0
    val markerFee = Billing.marker(markers, now).amount
    val working = markers.count { it.endTime == null }

    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(
            containerColor = if (active) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(start = 14.dp, top = 6.dp, end = 6.dp, bottom = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    table.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                if (canEdit) IconButton(onClick = onEdit) {
                    Icon(Icons.Filled.Edit, contentDescription = "ပြင်ရန်")
                }
            }
            if (!table.isCounter) {
                Text(
                    table.tableSize().label,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            when {
                table.isCounter -> {
                    Text(
                        if (active) "ပစ္စည်း ${tableItems.sumOf { it.qty }} ခု" else "ပစ္စည်းရောင်းရန်",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (active) {
                        Text(
                            Fmt.ks(itemsAmount),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                start != null -> {
                    Text(
                        Fmt.clock(now - start),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (working > 0) Text(
                        "မာကာ $working ယောက်",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        Fmt.ks(play + markerFee + itemsAmount),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                else -> {
                    Text("လွတ်နေသည်", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "${Fmt.ks(table.ratePerHour)} / နာရီ",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun TableDialog(
    initial: BilliardTable?,
    bigRate: Int,
    smallRate: Int,
    onSave: (name: String, size: TableSize) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var size by remember { mutableStateOf(initial?.tableSize() ?: TableSize.BIG) }
    val isCounter = initial?.isCounter == true

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "ခုံအသစ် ထည့်ရန်" else "ခုံ ပြင်ရန်") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("အမည်") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (!isCounter) {
                    Text("ခုံအရွယ်အစား", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TableSize.entries.forEach { option ->
                            FilterChip(
                                selected = size == option,
                                onClick = { size = option },
                                label = { Text(option.label) }
                            )
                        }
                    }
                    val rate = if (size == TableSize.BIG) bigRate else smallRate
                    Text(
                        "${Fmt.ks(rate)} / နာရီ (ဆက်တင်တွင် ဈေးပြောင်းနိုင်သည်)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text("ဤခုံကို ဖျက်မည်", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name.trim(), size) },
                enabled = name.isNotBlank()
            ) { Text("သိမ်းမည်") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("မလုပ်တော့ပါ") } }
    )
}

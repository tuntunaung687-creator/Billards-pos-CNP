package com.example.billiardpos.util

import com.example.billiardpos.data.MarkerStint
import com.example.billiardpos.data.Sale
import com.example.billiardpos.data.SaleItem
import com.example.billiardpos.data.TableItem

/** Plain-text bill, for sharing to a second phone (Viber, Telegram, Messenger ...). */
object BillText {
    private fun row(label: String, amount: Int) = "$label  ${Fmt.ks(amount)}"

    fun forSale(shop: String, footer: String, sale: Sale, items: List<SaleItem>): String =
        build(
            shop = shop,
            title = "ဘောက်ချာ အမှတ် ${sale.id}",
            whenText = Fmt.dateTime(sale.createdAt),
            table = sale.tableName,
            staff = sale.staffName,
            startText = sale.startTime?.let { "${Fmt.time(it)} - ${Fmt.time(sale.endTime)}" },
            minutes = sale.minutes,
            play = sale.playAmount,
            markerMinutes = sale.markerMinutes,
            marker = sale.markerAmount,
            lines = items.map { Triple(it.name, it.qty, it.price) },
            discount = sale.discount,
            total = sale.total,
            footer = footer
        )

    /** Preview of a bill that is still running (not saved, not paid). */
    fun forRunning(
        shop: String,
        tableName: String,
        start: Long?,
        now: Long,
        play: Int,
        stints: List<MarkerStint>,
        items: List<TableItem>
    ): String {
        val marker = Billing.marker(stints, now)
        val itemsAmount = items.sumOf { it.price * it.qty }
        return build(
            shop = shop,
            title = "ဘေစာရွက် (ငွေမရှင်းရသေးပါ)",
            whenText = Fmt.dateTime(now),
            table = tableName,
            staff = "",
            startText = start?.let { "${Fmt.time(it)} - ${Fmt.time(now)}" },
            minutes = if (start != null) Billing.minutes(start, now) else 0,
            play = play,
            markerMinutes = marker.minutes,
            marker = marker.amount,
            lines = items.map { Triple(it.name, it.qty, it.price) },
            discount = 0,
            total = play + marker.amount + itemsAmount,
            footer = ""
        )
    }

    private fun build(
        shop: String,
        title: String,
        whenText: String,
        table: String,
        staff: String,
        startText: String?,
        minutes: Int,
        play: Int,
        markerMinutes: Int,
        marker: Int,
        lines: List<Triple<String, Int, Int>>,
        discount: Int,
        total: Int,
        footer: String
    ): String = buildString {
        appendLine(shop)
        appendLine(title)
        appendLine(whenText)
        appendLine("ခုံ: $table" + if (staff.isNotBlank()) "   ဝန်ထမ်း: $staff" else "")
        appendLine("--------------------")
        if (startText != null) {
            appendLine(startText)
            appendLine(row("ခုံကြေး (${Fmt.hm(minutes)})", play))
        }
        if (marker > 0) appendLine(row("မာကာကြေး (${Fmt.hm(markerMinutes)})", marker))
        if (lines.isNotEmpty()) {
            appendLine("--------------------")
            lines.forEach { (name, qty, price) -> appendLine(row("$name x$qty", price * qty)) }
            appendLine(row("အခြားရောင်းရငွေ", lines.sumOf { it.second * it.third }))
        }
        appendLine("--------------------")
        if (discount > 0) appendLine(row("လျှော့ငွေ", -discount))
        appendLine(row("စုစုပေါင်း", total))
        if (footer.isNotBlank()) {
            appendLine("--------------------")
            appendLine(footer)
        }
    }.trimEnd()
}

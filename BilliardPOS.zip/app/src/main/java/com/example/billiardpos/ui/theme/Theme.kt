package com.example.billiardpos.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PosColors = lightColorScheme(
    primary = Color(0xFF0B6E4F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFBFEBD8),
    onPrimaryContainer = Color(0xFF002114),
    secondary = Color(0xFF8D6E2F),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE9B0),
    onSecondaryContainer = Color(0xFF2B1F00),
    background = Color(0xFFF6FAF7),
    surface = Color.White
)

@Composable
fun PosTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = PosColors, content = content)
}

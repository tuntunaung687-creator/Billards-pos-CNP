package com.example.billiardpos.print

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.billiardpos.data.Sale
import com.example.billiardpos.data.SaleItem
import com.example.billiardpos.util.Fmt

data class Receipt(
    val shopName: String,
    val footer: String,
    val sale: Sale,
    val items: List<SaleItem>
)

/**
 * Draws the receipt as a bitmap. Thermal printers rarely ship a Myanmar font,
 * so we render the text with Android's own text engine and print the image.
 */
object ReceiptRenderer {

    fun render(receipt: Receipt, widthPx: Int): Bitmap {
        val sale = receipt.sale
        val margin = 6f
        val contentW = (widthPx - margin * 2).toInt()
        val base = if (widthPx >= 576) 30f else 24f

        val normal = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = base
        }
        val bold = TextPaint(normal).apply { typeface = Typeface.DEFAULT_BOLD }
        val big = TextPaint(bold).apply { textSize = base * 1.5f }

        val estimatedHeight = 900 + receipt.items.size * (base * 5).toInt()
        val bitmap = Bitmap.createBitmap(widthPx, estimatedHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        var y = 8f

        fun center(text: String, paint: TextPaint) {
            val layout = StaticLayout.Builder
                .obtain(text, 0, text.length, paint, contentW)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .build()
            canvas.save()
            canvas.translate(margin, y)
            layout.draw(canvas)
            canvas.restore()
            y += layout.height
        }

        fun leftRight(left: String, right: String, paint: TextPaint) {
            val rightW = paint.measureText(right)
            val leftW = (contentW - rightW - 10f).toInt().coerceAtLeast(60)
            val layout = StaticLayout.Builder
                .obtain(left, 0, left.length, paint, leftW)
                .build()
            canvas.save()
            canvas.translate(margin, y)
            layout.draw(canvas)
            canvas.restore()
            canvas.drawText(right, margin + contentW - rightW, y + layout.getLineBaseline(0), paint)
            y += layout.height
        }

        fun divider() {
            val p = Paint().apply {
                color = Color.BLACK
                strokeWidth = 2f
                pathEffect = DashPathEffect(floatArrayOf(6f, 6f), 0f)
            }
            canvas.drawLine(margin, y + 8f, margin + contentW, y + 8f, p)
            y += 18f
        }

        center(receipt.shopName, big)
        y += 4f
        center("ဘောက်ချာ အမှတ် ${sale.id}", normal)
        center(Fmt.dateTime(sale.createdAt), normal)
        divider()

        leftRight("ခုံ", sale.tableName, bold)
        val start = sale.startTime
        if (start != null) {
            leftRight("စတင်ချိန်", Fmt.time(start), normal)
            leftRight("ပြီးဆုံးချိန်", Fmt.time(sale.endTime), normal)
            leftRight("ခုံကြေး (${Fmt.hm(sale.minutes)})", Fmt.ks(sale.playAmount), bold)
        }

        if (receipt.items.isNotEmpty()) {
            divider()
            receipt.items.forEach { item ->
                leftRight("${item.name} x${item.qty}", Fmt.ks(item.price * item.qty), normal)
            }
            leftRight("အခြားရောင်းရငွေ", Fmt.ks(sale.itemsAmount), bold)
        }

        divider()
        if (sale.discount > 0) {
            leftRight("လျှော့ငွေ", "-" + Fmt.ks(sale.discount), normal)
        }
        leftRight("စုစုပေါင်း", Fmt.ks(sale.total), big)
        divider()

        if (receipt.footer.isNotBlank()) {
            center(receipt.footer, normal)
        }
        y += 24f

        val height = (y + 8f).toInt().coerceIn(1, estimatedHeight)
        val result = Bitmap.createBitmap(bitmap, 0, 0, widthPx, height)
        bitmap.recycle()
        return result
    }
}

package com.example.billiardpos.print

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.UUID

data class PrinterDevice(val name: String, val address: String)

/** Sends ESC/POS data to a paired Bluetooth (SPP) thermal printer. */
class BluetoothPrinter(private val context: Context) {

    private val adapter
        get() = context.getSystemService(BluetoothManager::class.java)?.adapter

    /** BLUETOOTH_CONNECT is a runtime permission only on Android 12+ (API 31). */
    fun hasPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun bondedDevices(): List<PrinterDevice> {
        val bt = adapter ?: return emptyList()
        if (!hasPermission()) return emptyList()
        return bt.bondedDevices.orEmpty()
            .map { PrinterDevice(it.name ?: it.address, it.address) }
            .sortedBy { it.name.lowercase() }
    }

    @SuppressLint("MissingPermission")
    suspend fun print(address: String, data: ByteArray): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val bt = adapter ?: error("ဤဖုန်းတွင် Bluetooth မရှိပါ")
                if (!hasPermission()) error("Bluetooth ခွင့်ပြုချက် မရသေးပါ")
                if (!bt.isEnabled) error("Bluetooth ကို ဖွင့်ပါ")

                val device = bt.getRemoteDevice(address)
                val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                try {
                    bt.cancelDiscovery()
                    socket.connect()
                    socket.outputStream.write(data)
                    socket.outputStream.flush()
                    // Give the printer time to drain its buffer before closing.
                    Thread.sleep(700)
                } finally {
                    try {
                        socket.close()
                    } catch (_: IOException) {
                    }
                }
            }
        }

    private companion object {
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }
}

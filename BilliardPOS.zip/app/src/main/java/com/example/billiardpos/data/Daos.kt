package com.example.billiardpos.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TableDao {
    @Query("SELECT * FROM billiard_tables ORDER BY isCounter, sortOrder, id")
    fun observeAll(): Flow<List<BilliardTable>>

    @Query("SELECT * FROM billiard_tables ORDER BY id")
    suspend fun getAll(): List<BilliardTable>

    @Query("SELECT * FROM billiard_tables WHERE id = :id")
    suspend fun get(id: Long): BilliardTable?

    @Query("SELECT COUNT(*) FROM billiard_tables")
    suspend fun count(): Int

    @Query("SELECT COALESCE(MAX(sortOrder), 0) FROM billiard_tables WHERE isCounter = 0")
    suspend fun maxSortOrder(): Int

    @Insert
    suspend fun insert(table: BilliardTable): Long

    @Insert
    suspend fun insertAll(tables: List<BilliardTable>)

    @Update
    suspend fun update(table: BilliardTable)

    @Delete
    suspend fun delete(table: BilliardTable)

    @Query("DELETE FROM billiard_tables")
    suspend fun deleteAll()

    @Query("UPDATE billiard_tables SET startTime = :start, sessionRate = :rate WHERE id = :id")
    suspend fun startSession(id: Long, start: Long, rate: Int)

    @Query("UPDATE billiard_tables SET startTime = NULL, sessionRate = 0 WHERE id = :id")
    suspend fun endSession(id: Long)

    /** Applies a new hourly rate to every (non-counter) table of one size. */
    @Query("UPDATE billiard_tables SET ratePerHour = :rate WHERE size = :size AND isCounter = 0")
    suspend fun setRateForSize(size: String, rate: Int)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE active = 1 ORDER BY category, name")
    fun observeActive(): Flow<List<Product>>

    @Query("SELECT * FROM products ORDER BY id")
    suspend fun getAll(): List<Product>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun get(id: Long): Product?

    @Insert
    suspend fun insert(product: Product): Long

    @Insert
    suspend fun insertAll(products: List<Product>)

    @Update
    suspend fun update(product: Product)

    @Query("DELETE FROM products")
    suspend fun deleteAll()

    @Query("UPDATE products SET stock = stock - :qty WHERE id = :id AND trackStock = 1")
    suspend fun decrementStock(id: Long, qty: Int)
}

@Dao
interface TableItemDao {
    @Query("SELECT * FROM table_items ORDER BY id")
    fun observeAll(): Flow<List<TableItem>>

    @Query("SELECT * FROM table_items ORDER BY id")
    suspend fun getAll(): List<TableItem>

    @Query("SELECT * FROM table_items WHERE tableId = :tableId ORDER BY id")
    suspend fun getFor(tableId: Long): List<TableItem>

    @Query("SELECT * FROM table_items WHERE tableId = :tableId AND productId = :productId LIMIT 1")
    suspend fun find(tableId: Long, productId: Long): TableItem?

    @Insert
    suspend fun insert(item: TableItem): Long

    @Insert
    suspend fun insertAll(items: List<TableItem>)

    @Update
    suspend fun update(item: TableItem)

    @Query("DELETE FROM table_items WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM table_items WHERE tableId = :tableId")
    suspend fun clearFor(tableId: Long)

    @Query("DELETE FROM table_items")
    suspend fun deleteAll()
}

@Dao
interface SaleDao {
    @Insert
    suspend fun insertSale(sale: Sale): Long

    @Insert
    suspend fun insertSales(sales: List<Sale>)

    @Insert
    suspend fun insertItems(items: List<SaleItem>)

    @Query("SELECT * FROM sales ORDER BY id")
    suspend fun getAllSales(): List<Sale>

    @Query("SELECT * FROM sale_items ORDER BY id")
    suspend fun getAllSaleItems(): List<SaleItem>

    @Query("DELETE FROM sale_items")
    suspend fun deleteAllSaleItems()

    @Query("DELETE FROM sales")
    suspend fun deleteAllSales()

    @Query("SELECT * FROM sales WHERE id = :id")
    suspend fun getSale(id: Long): Sale?

    @Query("SELECT * FROM sale_items WHERE saleId = :saleId ORDER BY id")
    suspend fun itemsFor(saleId: Long): List<SaleItem>

    @Query("SELECT * FROM sales WHERE createdAt BETWEEN :from AND :to ORDER BY createdAt DESC")
    fun observeBetween(from: Long, to: Long): Flow<List<Sale>>

    @Query(
        """
        SELECT name AS name, SUM(qty) AS qty, SUM(price * qty) AS amount
        FROM sale_items
        WHERE saleId IN (SELECT id FROM sales WHERE createdAt BETWEEN :from AND :to)
        GROUP BY name
        ORDER BY qty DESC
        LIMIT 10
        """
    )
    fun observeTopProducts(from: Long, to: Long): Flow<List<TopProduct>>

    /**
     * Totals grouped by a strftime pattern ("%Y-%m" for months, "%Y" for years).
     * [offset] is the device's UTC offset in millis so days/months follow local time.
     */
    @Query(
        """
        SELECT strftime(:pattern, (createdAt + :offset) / 1000, 'unixepoch') AS period,
               COALESCE(SUM(playAmount), 0) AS play,
               COALESCE(SUM(itemsAmount), 0) AS items,
               COALESCE(SUM(discount), 0) AS discount,
               COALESCE(SUM(total), 0) AS total,
               COUNT(*) AS billCount
        FROM sales
        WHERE createdAt BETWEEN :from AND :to
        GROUP BY period
        ORDER BY period
        """
    )
    fun observeSummary(pattern: String, offset: Long, from: Long, to: Long): Flow<List<PeriodSummary>>
}

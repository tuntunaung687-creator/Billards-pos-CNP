package com.example.billiardpos.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tableTab = Tab("tables", "ခုံများ", Icons.Filled.GridView)
private val staffTabs = listOf(tableTab)
private val adminTabs = listOf(
    tableTab,
    Tab("products", "ပစ္စည်းများ", Icons.Filled.Inventory2),
    Tab("report", "ရောင်းအား", Icons.Filled.BarChart),
    Tab("settings", "ဆက်တင်", Icons.Filled.Settings)
)

/** Decides what to show: first-run setup, PIN login, or the app itself. */
@Composable
fun PosApp(vm: PosViewModel = viewModel()) {
    val snackbar = remember { SnackbarHostState() }
    val staffCount by vm.staffCount.collectAsStateWithLifecycle()
    val user by vm.currentUser.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        vm.messages.collect { snackbar.showSnackbar(it) }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        val modifier = Modifier.padding(padding)
        val current = user
        when {
            staffCount == null -> Box(modifier.fillMaxSize())
            staffCount == 0 -> SetupScreen(vm)
            current == null -> LoginScreen(vm)
            // Keyed by person so every login starts on the first screen of that role.
            else -> key(current.id) {
                MainApp(vm = vm, isAdmin = current.role == "ADMIN", modifier = modifier)
            }
        }
    }
}

@Composable
private fun MainApp(vm: PosViewModel, isAdmin: Boolean, modifier: Modifier = Modifier) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val tabs = if (isAdmin) adminTabs else staffTabs

    Scaffold(
        modifier = modifier,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            // Staff only have one screen, so no tab bar for them.
            if (tabs.size > 1 && tabs.any { it.route == route }) {
                NavigationBar {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = {
                                nav.navigate(tab.route) {
                                    popUpTo("tables") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "tables",
            modifier = Modifier.padding(padding)
        ) {
            composable("tables") {
                TablesScreen(vm, onOpen = { id -> nav.navigate("table/$id") })
            }
            composable(
                route = "table/{id}",
                arguments = listOf(navArgument("id") { type = NavType.LongType })
            ) { entry ->
                TableDetailScreen(
                    vm = vm,
                    tableId = entry.arguments?.getLong("id") ?: 0L,
                    onBack = { nav.popBackStack() }
                )
            }
            if (isAdmin) {
                composable("products") { ProductsScreen(vm) }
                composable("report") { ReportScreen(vm) }
                composable("settings") { SettingsScreen(vm) }
            }
        }
    }
}

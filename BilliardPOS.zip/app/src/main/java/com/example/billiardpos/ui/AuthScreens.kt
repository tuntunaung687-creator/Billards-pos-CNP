@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.billiardpos.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.billiardpos.data.Role
import com.example.billiardpos.util.Pin

/** PIN input: digits only, hidden, number keyboard. */
@Composable
fun PinField(
    value: String,
    label: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    imeAction: ImeAction = ImeAction.Next,
    onDone: () -> Unit = {}
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit).take(Pin.MAX_LENGTH)) },
        label = { Text(label) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = imeAction),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        modifier = modifier
    )
}

@Composable
fun LoginScreen(vm: PosViewModel) {
    val staff by vm.staffList.collectAsStateWithLifecycle()
    val active = staff.filter { it.active }
    var selectedId by rememberSaveable { mutableStateOf<Long?>(null) }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    // Falls back to the first person when nothing (or a removed account) is selected.
    val chosen = active.firstOrNull { it.id == selectedId } ?: active.firstOrNull()

    fun submit() {
        val id = chosen?.id ?: return
        if (busy || pin.length < Pin.MIN_LENGTH) return
        busy = true
        vm.login(id, pin) { message ->
            busy = false
            error = message
            if (message != null) pin = ""
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Billiard POS",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "ဝန်ထမ်းအမည်ရွေးပြီး PIN ရိုက်ပါ",
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
        )
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
        ) {
            active.forEach { person ->
                FilterChip(
                    selected = person.id == chosen?.id,
                    onClick = {
                        selectedId = person.id
                        pin = ""
                        error = null
                    },
                    label = { Text(person.name) }
                )
            }
        }
        PinField(
            value = pin,
            label = "PIN",
            onChange = {
                pin = it
                error = null
            },
            imeAction = ImeAction.Done,
            onDone = { submit() },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        )
        error?.let {
            Text(
                it,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        Button(
            onClick = { submit() },
            enabled = chosen != null && pin.length >= Pin.MIN_LENGTH && !busy,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        ) { Text("ဝင်မည်") }
    }
}

/** Shown once, on the very first run, to create the first Admin. */
@Composable
fun SetupScreen(vm: PosViewModel) {
    var name by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    val mismatch = confirm.isNotEmpty() && pin != confirm
    val valid = name.isNotBlank() && Pin.isValid(pin) && pin == confirm

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Billiard POS",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "ပထမဆုံး Admin (ပိုင်ရှင်) အကောင့် ဖန်တီးပါ",
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
        )
        Text(
            "PIN ကို ${Pin.MIN_LENGTH}-${Pin.MAX_LENGTH} လုံး ဂဏန်းဖြင့် ပေးပါ။ မေ့သွားလျှင် ပြန်ယူ၍ မရနိုင်သဖြင့် မှတ်ထားပါ။",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 20.dp)
        )
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("အမည်") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        PinField(
            value = pin,
            label = "PIN",
            onChange = { pin = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp)
        )
        PinField(
            value = confirm,
            label = "PIN ထပ်ရိုက်ပါ",
            onChange = { confirm = it },
            imeAction = ImeAction.Done,
            onDone = { if (valid) vm.setupAdmin(name, pin) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp)
        )
        if (mismatch) {
            Text(
                "PIN နှစ်ခု မတူပါ",
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        Button(
            onClick = { vm.setupAdmin(name, pin) },
            enabled = valid,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        ) { Text("Admin ဖန်တီးမည်") }
    }
}

/** Role chips used by the "add staff" dialog. */
@Composable
fun RoleChips(selected: Role, onSelect: (Role) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Role.entries.forEach { role ->
            FilterChip(
                selected = role == selected,
                onClick = { onSelect(role) },
                label = { Text(role.label) }
            )
        }
    }
}

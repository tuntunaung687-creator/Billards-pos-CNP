@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.billiardpos.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.billiardpos.data.Role
import com.example.billiardpos.data.Staff
import com.example.billiardpos.data.roleEnum
import com.example.billiardpos.util.Pin

/** Admin-only list of staff accounts inside Settings. */
@Composable
fun StaffSection(vm: PosViewModel) {
    val staff by vm.staffList.collectAsStateWithLifecycle()
    val me by vm.currentUser.collectAsStateWithLifecycle()
    var adding by remember { mutableStateOf(false) }
    var resetFor by remember { mutableStateOf<Staff?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        staff.forEach { person ->
            Card(Modifier.fillMaxWidth()) {
                Column {
                    ListItem(
                        headlineContent = {
                            Text(person.name + if (person.id == me?.id) "  (ကျွန်ုပ်)" else "")
                        },
                        supportingContent = {
                            Text(
                                person.roleEnum().label + if (person.active) "" else "  •  ပိတ်ထားသည်",
                                color = if (person.active) {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                } else {
                                    MaterialTheme.colorScheme.error
                                }
                            )
                        }
                    )
                    Row(Modifier.padding(horizontal = 8.dp)) {
                        TextButton(onClick = { resetFor = person }) { Text("PIN ပြောင်း") }
                        TextButton(onClick = { vm.setStaffActive(person.id, !person.active) }) {
                            Text(if (person.active) "ပိတ်မည်" else "ပြန်ဖွင့်မည်")
                        }
                    }
                }
            }
        }
        OutlinedButton(onClick = { adding = true }) { Text("ဝန်ထမ်းအသစ် ထည့်မည်") }
        Text(
            "Staff သည် ခုံဖွင့်၊ ပစ္စည်းထည့်၊ ငွေရှင်း၊ ဘောက်ချာထုတ်ရုံသာ လုပ်နိုင်ပါသည်။ ဈေးနှုန်း၊ ပစ္စည်းစာရင်း၊ လျှော့ငွေ၊ ပယ်ဖျက်ခြင်း၊ report၊ ဆက်တင်များသည် Admin သာ လုပ်နိုင်ပါသည်။ Admin PIN မေ့သွားမည်ကို စိုးလျှင် Admin နှစ်ယောက် ထားပါ။",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    if (adding) {
        AddStaffDialog(
            onSave = { name, role, pin ->
                vm.addStaff(name, role, pin)
                adding = false
            },
            onDismiss = { adding = false }
        )
    }
    resetFor?.let { person ->
        ResetPinDialog(
            name = person.name,
            onSave = { pin ->
                vm.resetPin(person.id, pin)
                resetFor = null
            },
            onDismiss = { resetFor = null }
        )
    }
}

@Composable
private fun AddStaffDialog(
    onSave: (name: String, role: Role, pin: String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(Role.STAFF) }
    var pin by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ဝန်ထမ်းအသစ်") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("အမည်") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                RoleChips(selected = role, onSelect = { role = it })
                PinField(
                    value = pin,
                    label = "PIN (${Pin.MIN_LENGTH}-${Pin.MAX_LENGTH} လုံး)",
                    onChange = { pin = it },
                    imeAction = ImeAction.Done,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name, role, pin) },
                enabled = name.isNotBlank() && Pin.isValid(pin)
            ) { Text("ထည့်မည်") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("မလုပ်တော့ပါ") } }
    )
}

@Composable
private fun ResetPinDialog(
    name: String,
    onSave: (pin: String) -> Unit,
    onDismiss: () -> Unit
) {
    var pin by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("$name — PIN အသစ်") },
        text = {
            PinField(
                value = pin,
                label = "PIN အသစ် (${Pin.MIN_LENGTH}-${Pin.MAX_LENGTH} လုံး)",
                onChange = { pin = it },
                imeAction = ImeAction.Done,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(onClick = { onSave(pin) }, enabled = Pin.isValid(pin)) { Text("ပြောင်းမည်") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("မလုပ်တော့ပါ") } }
    )
}

/** Admin-only list of marker names (the people who can be assigned to tables). */
@Composable
fun MarkerPeopleSection(vm: PosViewModel) {
    val people by vm.markerPeople.collectAsStateWithLifecycle()
    var name by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        people.forEach { p ->
            Card(Modifier.fillMaxWidth()) {
                ListItem(
                    headlineContent = { Text(p.name) },
                    supportingContent = { if (!p.active) Text("ပိတ်ထားသည်") },
                    trailingContent = {
                        TextButton(onClick = { vm.setMarkerPersonActive(p.id, !p.active) }) {
                            Text(if (p.active) "ပိတ်မည်" else "ပြန်ဖွင့်မည်")
                        }
                    }
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("မာကာ အမည်") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = { vm.addMarkerPerson(name); name = "" },
                enabled = name.isNotBlank()
            ) { Text("ထည့်မည်") }
        }
        Text(
            "ခုံတွင် မာကာ ထည့်ရာ၌ ဤစာရင်းမှ ရွေးရပါမည်။ လကုန်တွင် မာကာတစ်ယောက်ချင်းစီ ရသင့်သော ငွေကို report တွင် ကြည့်နိုင်သည်။",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.billiardpos.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.billiardpos.data.MarkerPaySummary
import com.example.billiardpos.data.PeriodSummary
import com.example.billiardpos.data.Sale
import com.example.billiardpos.data.SaleItem
import com.example.billiardpos.data.TopProduct
import com.example.billiardpos.util.Csv
import com.example.billiardpos.util.Fmt
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class ReportMode(val label: String) {
    BILLS("ဘောက်ချာ"),
    MONTHLY("လချုပ်"),
    YEARLY("နှစ်ချုပ်")
}

/** "2026-03" -> "မတ် 2026" */
private fun monthLabel(period: String): String {
    val month0 = period.substringAfter('-', "").toIntOrNull()?.minus(1) ?: return period
    return "${Fmt.monthName(month0)} ${period.substringBefore('-')}"
}

@Composable
fun ReportScreen(vm: PosViewModel, modifier: Modifier = Modifier) {
    val range by vm.billRange.collectAsStateWithLifecycle()
    val sales by vm.sales.collectAsStateWithLifecycle()
    val top by vm.topProducts.collectAsStateWithLifecycle()
    val markerPay by vm.markerPay.collectAsStateWithLifecycle()
    val monthly by vm.monthly.collectAsStateWithLifecycle()
    val yearly by vm.yearly.collectAsStateWithLifecycle()
    val year by vm.summaryYear.collectAsStateWithLifecycle()

    var mode by rememberSaveable { mutableStateOf(ReportMode.BILLS) }
    var selected by remember { mutableStateOf<Sale?>(null) }
    var pendingCsv by remember { mutableStateOf<String?>(null) }

    val csvLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        val text = pendingCsv
        if (uri != null && text != null) vm.saveText(uri, text)
        pendingCsv = null
    }

    // Always 12 rows for the selected year, months without sales show zero.
    val byPeriod = monthly.associateBy { it.period }
    val monthRows = (0..11).map { m ->
        val key = String.format(Locale.US, "%04d-%02d", year, m + 1)
        m to (byPeriod[key] ?: PeriodSummary(key, 0, 0, 0, 0, 0, 0))
    }

    fun exportCsv() {
        when (mode) {
            ReportMode.BILLS -> {
                pendingCsv = Csv.bills(sales)
                csvLauncher.launch("bills-${SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())}.csv")
            }
            ReportMode.MONTHLY -> {
                pendingCsv = Csv.summary("လ", monthly) { monthLabel(it) }
                csvLauncher.launch("monthly-$year.csv")
            }
            ReportMode.YEARLY -> {
                pendingCsv = Csv.summary("နှစ်", yearly) { it }
                csvLauncher.launch("yearly.csv")
            }
        }
    }

    Column(modifier.fillMaxSize()) {
        PosTopBar("ရောင်းအား အစီရင်ခံစာ")
        LazyColumn(
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ReportMode.entries.forEach { m ->
                        FilterChip(
                            selected = mode == m,
                            onClick = { mode = m },
                            label = { Text(m.label) }
                        )
                    }
                }
            }
            item {
                OutlinedButton(onClick = { exportCsv() }) { Text("CSV ထုတ်မည် (Excel)") }
            }

            when (mode) {
                ReportMode.BILLS -> billsSection(
                    range = range,
                    sales = sales,
                    top = top,
                    markerPay = markerPay,
                    onRange = { vm.selectRange(it) },
                    onOpen = { selected = it }
                )
                ReportMode.MONTHLY -> monthlySection(
                    year = year,
                    rows = monthRows,
                    onYear = { vm.summaryYear.value = it },
                    onMonth = { m ->
                        vm.selectMonth(year, m)
                        mode = ReportMode.BILLS
                    }
                )
                ReportMode.YEARLY -> yearlySection(
                    rows = yearly,
                    onYear = { y ->
                        vm.selectYear(y)
                        mode = ReportMode.BILLS
                    }
                )
            }
        }
    }

    selected?.let { sale ->
        SaleDialog(vm = vm, sale = sale, onDismiss = { selected = null })
    }
}

// ---- ဘောက်ချာ -------------------------------------------------------------

private fun LazyListScope.billsSection(
    range: RangeSel,
    sales: List<Sale>,
    top: List<TopProduct>,
    markerPay: List<MarkerPaySummary>,
    onRange: (ReportRange) -> Unit,
    onOpen: (Sale) -> Unit
) {
    item {
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ReportRange.entries.forEach { r ->
                FilterChip(
                    selected = range.label == r.label,
                    onClick = { onRange(r) },
                    label = { Text(r.label) }
                )
            }
            // A month / year picked from လချုပ် or နှစ်ချုပ်.
            if (ReportRange.entries.none { it.label == range.label }) {
                FilterChip(selected = true, onClick = {}, label = { Text(range.label) })
            }
        }
    }
    item {
        Breakdown(
            title = "${range.label} ရောင်းအား",
            play = sales.sumOf { it.playAmount },
            marker = sales.sumOf { it.markerAmount },
            items = sales.sumOf { it.itemsAmount },
            discount = sales.sumOf { it.discount },
            total = sales.sumOf { it.total },
            count = sales.size
        )
    }
    if (markerPay.isNotEmpty()) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "မာကာ လခ (${range.label})",
                        style = MaterialTheme.typography.labelLarge
                    )
                    markerPay.forEach {
                        SummaryLine(
                            "${it.name.ifBlank { "(အမည်မရှိ)" }}  •  ${Fmt.hm(it.minutes)}",
                            Fmt.ks(it.amount)
                        )
                    }
                    HorizontalDivider(Modifier.padding(vertical = 4.dp))
                    SummaryLine("စုစုပေါင်း", Fmt.ks(markerPay.sumOf { it.amount }), bold = true)
                }
            }
        }
    }
    if (top.isNotEmpty()) {
        item {
            Text(
                "ရောင်းရသော ပစ္စည်းစာရင်း",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    top.forEach { t ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${t.name}  x${t.qty}", modifier = Modifier.weight(1f))
                            Text(Fmt.ks(t.amount), fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
    item {
        Text(
            "ဘောက်ချာများ (${sales.size})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
    }
    if (sales.isEmpty()) {
        item {
            Text(
                "ဤကာလအတွင်း ရောင်းချမှု မရှိသေးပါ",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
    items(sales, key = { it.id }) { sale ->
        Card(Modifier.fillMaxWidth()) {
            ListItem(
                headlineContent = { Text("#${sale.id}  •  ${sale.tableName}") },
                supportingContent = {
                    Column {
                        Text(
                            Fmt.dateTime(sale.createdAt) +
                                if (sale.staffName.isNotBlank()) "  •  ${sale.staffName}" else ""
                        )
                        Text(
                            "ခုံကြေး ${Fmt.ks(sale.playAmount)}  •  မာကာ ${Fmt.ks(sale.markerAmount)}  •  အခြား ${Fmt.ks(sale.itemsAmount)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                trailingContent = { Text(Fmt.ks(sale.total), fontWeight = FontWeight.Bold) },
                modifier = Modifier.clickable { onOpen(sale) }
            )
        }
    }
}

// ---- လချုပ် ---------------------------------------------------------------

private fun LazyListScope.monthlySection(
    year: Int,
    rows: List<Pair<Int, PeriodSummary>>,
    onYear: (Int) -> Unit,
    onMonth: (Int) -> Unit
) {
    item {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            TextButton(onClick = { onYear(year - 1) }) { Text("◀") }
            Text(
                "$year",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            TextButton(onClick = { onYear(year + 1) }) { Text("▶") }
        }
    }
    item {
        Breakdown(
            title = "$year ခုနှစ် စုစုပေါင်း",
            play = rows.sumOf { it.second.play },
            marker = rows.sumOf { it.second.marker },
            items = rows.sumOf { it.second.items },
            discount = rows.sumOf { it.second.discount },
            total = rows.sumOf { it.second.total },
            count = rows.sumOf { it.second.billCount }
        )
    }
    item {
        Text(
            "လအလိုက် (နှိပ်၍ ဘောက်ချာများ ကြည့်ပါ)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
    }
    items(rows, key = { it.first }) { (month0, summary) ->
        PeriodCard(
            label = Fmt.monthName(month0),
            summary = summary,
            onClick = if (summary.billCount > 0) ({ onMonth(month0) }) else null
        )
    }
}

// ---- နှစ်ချုပ် -------------------------------------------------------------

private fun LazyListScope.yearlySection(
    rows: List<PeriodSummary>,
    onYear: (Int) -> Unit
) {
    item {
        Breakdown(
            title = "စုစုပေါင်း (နှစ်အားလုံး)",
            play = rows.sumOf { it.play },
            marker = rows.sumOf { it.marker },
            items = rows.sumOf { it.items },
            discount = rows.sumOf { it.discount },
            total = rows.sumOf { it.total },
            count = rows.sumOf { it.billCount }
        )
    }
    item {
        Text(
            "နှစ်အလိုက် (နှိပ်၍ ဘောက်ချာများ ကြည့်ပါ)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
    }
    if (rows.isEmpty()) {
        item {
            Text("ရောင်းချမှု မရှိသေးပါ", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    items(rows.asReversed(), key = { it.period }) { summary ->
        val y = summary.period.toIntOrNull()
        PeriodCard(
            label = "${summary.period} ခုနှစ်",
            summary = summary,
            onClick = if (y != null) ({ onYear(y) }) else null
        )
    }
}

// ---- Shared pieces -------------------------------------------------------

/** Total sales with ခုံကြေး and အခြားရောင်းရငွေ shown separately. */
@Composable
private fun Breakdown(
    title: String,
    play: Int,
    marker: Int,
    items: Int,
    discount: Int,
    total: Int,
    count: Int
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(
                Fmt.ks(total),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AmountBox("ခုံကြေး", play, Modifier.weight(1f))
                AmountBox("မာကာကြေး", marker, Modifier.weight(1f))
                AmountBox("အခြားရောင်းရငွေ", items, Modifier.weight(1f))
            }
            if (discount > 0) SummaryLine("လျှော့ငွေ", "-" + Fmt.ks(discount))
            SummaryLine("ဘောက်ချာ အရေအတွက်", "$count")
        }
    }
}

@Composable
private fun AmountBox(label: String, amount: Int, modifier: Modifier = Modifier) {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = MaterialTheme.shapes.medium,
        modifier = modifier
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(
                Fmt.ks(amount),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun PeriodCard(label: String, summary: PeriodSummary, onClick: (() -> Unit)?) {
    Card(
        onClick = { onClick?.invoke() },
        enabled = onClick != null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "ဘောက်ချာ ${summary.billCount} ခု",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("ခုံကြေး ${Fmt.ks(summary.play)}", style = MaterialTheme.typography.bodySmall)
                Text("မာကာ ${Fmt.ks(summary.marker)}", style = MaterialTheme.typography.bodySmall)
                Text("အခြား ${Fmt.ks(summary.items)}", style = MaterialTheme.typography.bodySmall)
                Text(
                    Fmt.ks(summary.total),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/** The bill slip: table fee and other sales listed separately. */
@Composable
private fun SaleDialog(vm: PosViewModel, sale: Sale, onDismiss: () -> Unit) {
    val lines by produceState(initialValue = emptyList<SaleItem>(), key1 = sale.id) {
        value = vm.getSaleItems(sale.id)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ဘောက်ချာ #${sale.id}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    "${sale.tableName}  •  ${Fmt.dateTime(sale.createdAt)}" +
                        if (sale.staffName.isNotBlank()) "  •  ဝန်ထမ်း ${sale.staffName}" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val start = sale.startTime
                if (start != null) {
                    SummaryLine(
                        "ခုံကြေး (${Fmt.time(start)} - ${Fmt.time(sale.endTime)}, ${Fmt.hm(sale.minutes)})",
                        Fmt.ks(sale.playAmount)
                    )
                }
                if (sale.markerAmount > 0) {
                    SummaryLine("မာကာကြေး (${Fmt.hm(sale.markerMinutes)})", Fmt.ks(sale.markerAmount))
                }
                if (lines.isNotEmpty()) {
                    HorizontalDivider()
                    lines.forEach { line ->
                        SummaryLine("${line.name} x${line.qty}", Fmt.ks(line.price * line.qty))
                    }
                    SummaryLine("အခြားရောင်းရငွေ", Fmt.ks(sale.itemsAmount), bold = true)
                }
                if (sale.discount > 0) SummaryLine("လျှော့ငွေ", "-" + Fmt.ks(sale.discount))
                HorizontalDivider()
                SummaryLine("စုစုပေါင်း", Fmt.ks(sale.total), bold = true)
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { vm.shareSale(sale.id) }) { Text("ဖုန်းသို့ ပို့မည်") }
                Button(onClick = { vm.printSale(sale.id) }) {
                    Icon(Icons.Filled.Print, contentDescription = null)
                    Text("ပြန်ပရင့်", modifier = Modifier.padding(start = 6.dp))
                }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ပိတ်မည်") } }
    )
}

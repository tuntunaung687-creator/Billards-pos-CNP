package com.example.billiardpos.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        BilliardTable::class,
        Product::class,
        TableItem::class,
        Sale::class,
        SaleItem::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tableDao(): TableDao
    abstract fun productDao(): ProductDao
    abstract fun itemDao(): TableItemDao
    abstract fun saleDao(): SaleDao

    companion object {
        /** v2: table sizes (12ft / 10ft) and the hourly rate locked per running session. */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE billiard_tables ADD COLUMN size TEXT NOT NULL DEFAULT 'SMALL'")
                db.execSQL("ALTER TABLE billiard_tables ADD COLUMN sessionRate INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE billiard_tables SET sessionRate = ratePerHour WHERE startTime IS NOT NULL")
            }
        }

        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "billiard_pos.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { instance = it }
            }
    }
}

package com.example.billiardpos.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        BilliardTable::class,
        Product::class,
        TableItem::class,
        Sale::class,
        SaleItem::class,
        Staff::class,
        MarkerStint::class,
        MarkerPerson::class,
        MarkerPay::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tableDao(): TableDao
    abstract fun productDao(): ProductDao
    abstract fun itemDao(): TableItemDao
    abstract fun saleDao(): SaleDao
    abstract fun staffDao(): StaffDao
    abstract fun markerDao(): MarkerDao
    abstract fun markerPersonDao(): MarkerPersonDao
    abstract fun markerPayDao(): MarkerPayDao

    companion object {
        /** v2: table sizes (12ft / 10ft) and the hourly rate locked per running session. */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE billiard_tables ADD COLUMN size TEXT NOT NULL DEFAULT 'SMALL'")
                db.execSQL("ALTER TABLE billiard_tables ADD COLUMN sessionRate INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE billiard_tables SET sessionRate = ratePerHour WHERE startTime IS NOT NULL")
            }
        }

        /** v3: staff accounts (PIN login) and the staff name stored on every sale. */
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `staff` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`name` TEXT NOT NULL, " +
                        "`role` TEXT NOT NULL, " +
                        "`salt` TEXT NOT NULL, " +
                        "`pinHash` TEXT NOT NULL, " +
                        "`active` INTEGER NOT NULL)"
                )
                db.execSQL("ALTER TABLE sales ADD COLUMN staffName TEXT NOT NULL DEFAULT ''")
            }
        }

        /** v4: markers charged by time, and the marker fee stored on every sale. */
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `marker_stints` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`tableId` INTEGER NOT NULL, " +
                        "`startTime` INTEGER NOT NULL, " +
                        "`endTime` INTEGER, " +
                        "`rate` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`tableId`) REFERENCES `billiard_tables`(`id`) " +
                        "ON UPDATE NO ACTION ON DELETE CASCADE)"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_marker_stints_tableId` ON `marker_stints` (`tableId`)")
                db.execSQL("ALTER TABLE sales ADD COLUMN markerAmount INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE sales ADD COLUMN markerMinutes INTEGER NOT NULL DEFAULT 0")
            }
        }

        /** v5: named markers and what each earned per bill (month-end payout). */
        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE marker_stints ADD COLUMN markerName TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `marker_people` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`name` TEXT NOT NULL, " +
                        "`active` INTEGER NOT NULL)"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `marker_pay` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`saleId` INTEGER NOT NULL, " +
                        "`markerName` TEXT NOT NULL, " +
                        "`minutes` INTEGER NOT NULL, " +
                        "`amount` INTEGER NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL)"
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_marker_pay_createdAt` ON `marker_pay` (`createdAt`)")
            }
        }

        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "billiard_pos.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                    .build()
                    .also { instance = it }
            }
    }
}

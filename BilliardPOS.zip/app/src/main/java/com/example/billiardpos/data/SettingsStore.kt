package com.example.billiardpos.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val shopName: String = "Billiard Club",
    val footer: String = "ကျေးဇူးတင်ပါသည်",
    val printerAddress: String = "",
    val printerName: String = "",
    val paper80: Boolean = false,
    val autoPrint: Boolean = true,
    /** Hourly rate of a 12 ft (big) table, in Kyat. */
    val bigRate: Int = 4_000,
    /** Hourly rate of a 10 ft (small) table, in Kyat. */
    val smallRate: Int = 3_000
) {
    fun rateFor(size: TableSize): Int = if (size == TableSize.BIG) bigRate else smallRate
}

/** Tiny SharedPreferences-backed settings holder. */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("pos_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            shopName = prefs.getString("shopName", d.shopName) ?: d.shopName,
            footer = prefs.getString("footer", d.footer) ?: d.footer,
            printerAddress = prefs.getString("printerAddress", d.printerAddress) ?: d.printerAddress,
            printerName = prefs.getString("printerName", d.printerName) ?: d.printerName,
            paper80 = prefs.getBoolean("paper80", d.paper80),
            autoPrint = prefs.getBoolean("autoPrint", d.autoPrint),
            bigRate = prefs.getInt("bigRate", d.bigRate),
            smallRate = prefs.getInt("smallRate", d.smallRate)
        )
    }

    fun update(transform: (AppSettings) -> AppSettings) {
        val next = transform(_state.value)
        _state.value = next
        prefs.edit()
            .putString("shopName", next.shopName)
            .putString("footer", next.footer)
            .putString("printerAddress", next.printerAddress)
            .putString("printerName", next.printerName)
            .putBoolean("paper80", next.paper80)
            .putBoolean("autoPrint", next.autoPrint)
            .putInt("bigRate", next.bigRate)
            .putInt("smallRate", next.smallRate)
            .apply()
    }
}

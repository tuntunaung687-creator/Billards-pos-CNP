package com.example.billiardpos.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

const val DEFAULT_SHOP_NAME = "CornerPocket Billards&Snooker club"

data class AppSettings(
    val shopName: String = DEFAULT_SHOP_NAME,
    val footer: String = "ကျေးဇူးတင်ပါသည်",
    val printerAddress: String = "",
    val printerName: String = "",
    val paper80: Boolean = false,
    val autoPrint: Boolean = true,
    /** Hourly rate of a 12 ft (big) table, in Kyat. */
    val bigRate: Int = 4_000,
    /** Hourly rate of a 10 ft (small) table, in Kyat. */
    val smallRate: Int = 3_000,
    /** မာကာကြေး: hourly fee per marker, in Kyat. */
    val markerRate: Int = 1_000,
    /** Google Apps Script web-app URL that receives bills (owner's online view). */
    val syncUrl: String = "",
    val syncToken: String = "",
    /** Highest sale id already uploaded. */
    val lastSyncedSaleId: Long = 0L
) {
    fun rateFor(size: TableSize): Int = if (size == TableSize.BIG) bigRate else smallRate
}

/** Tiny SharedPreferences-backed settings holder. */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("pos_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            shopName = (prefs.getString("shopName", d.shopName) ?: d.shopName)
                .let { if (it == "Billiard Club") d.shopName else it },
            footer = prefs.getString("footer", d.footer) ?: d.footer,
            printerAddress = prefs.getString("printerAddress", d.printerAddress) ?: d.printerAddress,
            printerName = prefs.getString("printerName", d.printerName) ?: d.printerName,
            paper80 = prefs.getBoolean("paper80", d.paper80),
            autoPrint = prefs.getBoolean("autoPrint", d.autoPrint),
            bigRate = prefs.getInt("bigRate", d.bigRate),
            smallRate = prefs.getInt("smallRate", d.smallRate),
            markerRate = prefs.getInt("markerRate", d.markerRate),
            syncUrl = prefs.getString("syncUrl", d.syncUrl) ?: d.syncUrl,
            syncToken = prefs.getString("syncToken", d.syncToken) ?: d.syncToken,
            lastSyncedSaleId = prefs.getLong("lastSyncedSaleId", d.lastSyncedSaleId)
        )
    }

    fun update(transform: (AppSettings) -> AppSettings) {
        val next = transform(_state.value)
        _state.value = next
        prefs.edit()
            .putString("shopName", next.shopName)
            .putString("footer", next.footer)
            .putString("printerAddress", next.printerAddress)
            .putString("printerName", next.printerName)
            .putBoolean("paper80", next.paper80)
            .putBoolean("autoPrint", next.autoPrint)
            .putInt("bigRate", next.bigRate)
            .putInt("smallRate", next.smallRate)
            .putInt("markerRate", next.markerRate)
            .putString("syncUrl", next.syncUrl)
            .putString("syncToken", next.syncToken)
            .putLong("lastSyncedSaleId", next.lastSyncedSaleId)
            .apply()
    }
}

package com.example.billiardpos.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Billing {
    /** Play charges are rounded UP to the nearest multiple of this amount (Kyat). */
    const val ROUND_UP_TO = 100

    /** Elapsed time in whole minutes, a started minute counts as a full minute. */
    fun minutes(start: Long, end: Long): Int =
        (((end - start).coerceAtLeast(0L) + 59_999L) / 60_000L).toInt()

    fun playAmount(ratePerHour: Int, minutes: Int): Int {
        if (minutes <= 0 || ratePerHour <= 0) return 0
        val raw = (ratePerHour.toLong() * minutes + 59L) / 60L
        return (((raw + ROUND_UP_TO - 1) / ROUND_UP_TO) * ROUND_UP_TO).toInt()
    }
}

object Fmt {
    fun ks(amount: Int): String = String.format(Locale.US, "%,d Ks", amount)

    /** Duration as HH:MM:SS. */
    fun clock(millis: Long): String {
        val total = (millis.coerceAtLeast(0L)) / 1000L
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    }

    fun hm(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        return if (h == 0) "$m မိနစ်" else "$h နာရီ $m မိနစ်"
    }

    fun time(millis: Long): String =
        SimpleDateFormat("HH:mm", Locale.US).format(Date(millis))

    private val MONTHS = listOf(
        "ဇန်နဝါရီ", "ဖေဖော်ဝါရီ", "မတ်", "ဧပြီ", "မေ", "ဇွန်",
        "ဇူလိုင်", "ဩဂုတ်", "စက်တင်ဘာ", "အောက်တိုဘာ", "နိုဝင်ဘာ", "ဒီဇင်ဘာ"
    )

    /** [month0] is zero based (0 = January). */
    fun monthName(month0: Int): String = MONTHS.getOrElse(month0) { "" }

    fun dateTime(millis: Long): String =
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(Date(millis))
}

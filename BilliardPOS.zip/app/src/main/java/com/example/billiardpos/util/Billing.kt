package com.example.billiardpos.util

import com.example.billiardpos.data.MarkerStint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Billing {
    /** Play charges are rounded UP to the nearest multiple of this amount (Kyat). */
    const val ROUND_UP_TO = 100

    /** Elapsed time in whole minutes, a started minute counts as a full minute. */
    fun minutes(start: Long, end: Long): Int =
        (((end - start).coerceAtLeast(0L) + 59_999L) / 60_000L).toInt()

    /**
     * မာကာကြေး for all stints of one table: every marker is charged for the minutes he worked
     * at the rate locked when he started; the total is rounded UP to [ROUND_UP_TO].
     * [minutes] is the combined marker minutes (two markers for 30 min each = 60).
     */
    fun marker(stints: List<MarkerStint>, now: Long): MarkerCharge {
        val lines = markerLines(stints, now)
        return MarkerCharge(lines.sumOf { it.amount }, lines.sumOf { it.minutes })
    }

    /**
     * One line per marker: his minutes and fee, rounded UP to [ROUND_UP_TO] per marker.
     * The bill's marker fee is the sum of these lines, and each line is what he is paid.
     */
    fun markerLines(stints: List<MarkerStint>, now: Long): List<MarkerLine> =
        stints.groupBy { it.markerName }.map { (name, list) ->
            var raw = 0L
            var minutes = 0
            list.forEach { stint ->
                val m = minutes(stint.startTime, stint.endTime ?: now)
                minutes += m
                raw += (stint.rate.toLong() * m + 59L) / 60L
            }
            val amount =
                if (raw <= 0) 0 else (((raw + ROUND_UP_TO - 1) / ROUND_UP_TO) * ROUND_UP_TO).toInt()
            MarkerLine(name, minutes, amount)
        }

    fun playAmount(ratePerHour: Int, minutes: Int): Int {
        if (minutes <= 0 || ratePerHour <= 0) return 0
        val raw = (ratePerHour.toLong() * minutes + 59L) / 60L
        return (((raw + ROUND_UP_TO - 1) / ROUND_UP_TO) * ROUND_UP_TO).toInt()
    }
}

data class MarkerCharge(val amount: Int, val minutes: Int)

data class MarkerLine(val name: String, val minutes: Int, val amount: Int)

object Fmt {
    fun ks(amount: Int): String = String.format(Locale.US, "%,d Ks", amount)

    /** Duration as HH:MM:SS. */
    fun clock(millis: Long): String {
        val total = (millis.coerceAtLeast(0L)) / 1000L
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    }

    fun hm(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        return if (h == 0) "$m မိနစ်" else "$h နာရီ $m မိနစ်"
    }

    fun time(millis: Long): String =
        SimpleDateFormat("HH:mm", Locale.US).format(Date(millis))

    private val MONTHS = listOf(
        "ဇန်နဝါရီ", "ဖေဖော်ဝါရီ", "မတ်", "ဧပြီ", "မေ", "ဇွန်",
        "ဇူလိုင်", "ဩဂုတ်", "စက်တင်ဘာ", "အောက်တိုဘာ", "နိုဝင်ဘာ", "ဒီဇင်ဘာ"
    )

    /** [month0] is zero based (0 = January). */
    fun monthName(month0: Int): String = MONTHS.getOrElse(month0) { "" }

    fun dateTime(millis: Long): String =
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(Date(millis))
}

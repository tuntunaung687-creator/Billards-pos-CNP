package com.example.billiardpos.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** Billiard table size. Each size has its own hourly rate (set in Settings). */
enum class TableSize(val label: String) {
    BIG("၁၂ ပေ"),
    SMALL("၁၀ ပေ");

    companion object {
        fun from(name: String?): TableSize = entries.firstOrNull { it.name == name } ?: SMALL
    }
}

/** A billiard table (or the special "counter" for direct product sales). */
@Entity(tableName = "billiard_tables")
data class BilliardTable(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    /** Current hourly rate of this table's size (copied from Settings when the rate changes). */
    val ratePerHour: Int,
    val isCounter: Boolean = false,
    /** Epoch millis when the current session started; null when the table is free. */
    val startTime: Long? = null,
    val sortOrder: Int = 0,
    /** [TableSize] name. */
    val size: String = TableSize.SMALL.name,
    /** Hourly rate locked when the session started, so a price change never re-prices a running table. */
    val sessionRate: Int = 0
)

fun BilliardTable.tableSize(): TableSize = TableSize.from(size)

/** Rate used for the running session (falls back to the current rate for sessions without a locked rate). */
fun BilliardTable.billingRate(): Int = if (sessionRate > 0) sessionRate else ratePerHour

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val price: Int,
    val category: String = "",
    val trackStock: Boolean = false,
    val stock: Int = 0,
    /** Soft delete flag so old sales keep their history. */
    val active: Boolean = true
)

/** An item added to a table's running (not yet paid) bill. */
@Entity(
    tableName = "table_items",
    foreignKeys = [
        ForeignKey(
            entity = BilliardTable::class,
            parentColumns = ["id"],
            childColumns = ["tableId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("tableId")]
)
data class TableItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tableId: Long,
    val productId: Long,
    val name: String,
    val price: Int,
    val qty: Int
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tableName: String,
    val startTime: Long?,
    val endTime: Long,
    val minutes: Int,
    /** ခုံကြေး (table fee). */
    val playAmount: Int,
    /** အခြားရောင်းရငွေ (drinks, food, other items). */
    val itemsAmount: Int,
    val discount: Int = 0,
    val total: Int,
    val createdAt: Long,
    /** Name of the staff member who closed the bill. */
    val staffName: String = "",
    /** မာကာကြေး (marker fee, charged by time). */
    val markerAmount: Int = 0,
    val markerMinutes: Int = 0
)

@Entity(
    tableName = "sale_items",
    foreignKeys = [
        ForeignKey(
            entity = Sale::class,
            parentColumns = ["id"],
            childColumns = ["saleId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("saleId")]
)
data class SaleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val name: String,
    val price: Int,
    val qty: Int
)

/** Result row of the "top products" report query. */
data class TopProduct(
    val name: String,
    val qty: Int,
    val amount: Int
)

/**
 * One marker (ball-racker / scorekeeper) working at a table. A marker is charged by time from
 * [startTime] until [endTime] (null while still working) at the [rate] locked when they started.
 * Adding another marker later simply opens another stint, so 1, 2 or more markers can overlap.
 */
@Entity(
    tableName = "marker_stints",
    foreignKeys = [
        ForeignKey(
            entity = BilliardTable::class,
            parentColumns = ["id"],
            childColumns = ["tableId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("tableId")]
)
data class MarkerStint(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tableId: Long,
    val startTime: Long,
    val endTime: Long? = null,
    val rate: Int,
    /** Name of the marker (a person), copied here so history survives renames. */
    val markerName: String = ""
)

/** A marker (ball-racker) who can be assigned to tables and is paid at month end. */
@Entity(tableName = "marker_people")
data class MarkerPerson(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val active: Boolean = true
)

/** What one marker earned on one closed bill - the basis of the month-end payout. */
@Entity(tableName = "marker_pay", indices = [Index("createdAt")])
data class MarkerPay(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val markerName: String,
    val minutes: Int,
    val amount: Int,
    val createdAt: Long
)

/** Total owed to one marker for a period. */
data class MarkerPaySummary(val name: String, val minutes: Int, val amount: Int)

enum class Role(val label: String) {
    ADMIN("Admin"),
    STAFF("Staff");

    companion object {
        fun from(name: String?): Role = entries.firstOrNull { it.name == name } ?: STAFF
    }
}

/** A person who can log in with a PIN. The PIN itself is never stored, only a salted hash. */
@Entity(tableName = "staff")
data class Staff(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    /** [Role] name. */
    val role: String = Role.STAFF.name,
    val salt: String,
    val pinHash: String,
    val active: Boolean = true
)

fun Staff.roleEnum(): Role = Role.from(role)

/** One month (period = "yyyy-MM") or one year (period = "yyyy") of the summary reports. */
data class PeriodSummary(
    val period: String,
    val play: Int,
    val marker: Int,
    val items: Int,
    val discount: Int,
    val total: Int,
    val billCount: Int
)

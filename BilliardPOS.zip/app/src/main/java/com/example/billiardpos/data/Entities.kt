package com.example.billiardpos.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** Billiard table size. Each size has its own hourly rate (set in Settings). */
enum class TableSize(val label: String) {
    BIG("၁၂ ပေ"),
    SMALL("၁၀ ပေ");

    companion object {
        fun from(name: String?): TableSize = entries.firstOrNull { it.name == name } ?: SMALL
    }
}

/** A billiard table (or the special "counter" for direct product sales). */
@Entity(tableName = "billiard_tables")
data class BilliardTable(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    /** Current hourly rate of this table's size (copied from Settings when the rate changes). */
    val ratePerHour: Int,
    val isCounter: Boolean = false,
    /** Epoch millis when the current session started; null when the table is free. */
    val startTime: Long? = null,
    val sortOrder: Int = 0,
    /** [TableSize] name. */
    val size: String = TableSize.SMALL.name,
    /** Hourly rate locked when the session started, so a price change never re-prices a running table. */
    val sessionRate: Int = 0
)

fun BilliardTable.tableSize(): TableSize = TableSize.from(size)

/** Rate used for the running session (falls back to the current rate for sessions without a locked rate). */
fun BilliardTable.billingRate(): Int = if (sessionRate > 0) sessionRate else ratePerHour

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val price: Int,
    val category: String = "",
    val trackStock: Boolean = false,
    val stock: Int = 0,
    /** Soft delete flag so old sales keep their history. */
    val active: Boolean = true
)

/** An item added to a table's running (not yet paid) bill. */
@Entity(
    tableName = "table_items",
    foreignKeys = [
        ForeignKey(
            entity = BilliardTable::class,
            parentColumns = ["id"],
            childColumns = ["tableId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("tableId")]
)
data class TableItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tableId: Long,
    val productId: Long,
    val name: String,
    val price: Int,
    val qty: Int
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tableName: String,
    val startTime: Long?,
    val endTime: Long,
    val minutes: Int,
    /** ခုံကြေး (table fee). */
    val playAmount: Int,
    /** အခြားရောင်းရငွေ (drinks, food, other items). */
    val itemsAmount: Int,
    val discount: Int = 0,
    val total: Int,
    val createdAt: Long
)

@Entity(
    tableName = "sale_items",
    foreignKeys = [
        ForeignKey(
            entity = Sale::class,
            parentColumns = ["id"],
            childColumns = ["saleId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("saleId")]
)
data class SaleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val name: String,
    val price: Int,
    val qty: Int
)

/** Result row of the "top products" report query. */
data class TopProduct(
    val name: String,
    val qty: Int,
    val amount: Int
)

/** One month (period = "yyyy-MM") or one year (period = "yyyy") of the summary reports. */
data class PeriodSummary(
    val period: String,
    val play: Int,
    val items: Int,
    val discount: Int,
    val total: Int,
    val billCount: Int
)

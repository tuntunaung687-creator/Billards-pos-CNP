package com.example.billiardpos.data

import androidx.room.withTransaction
import com.example.billiardpos.util.Billing

class PosRepository(private val db: AppDatabase) {
    private val tableDao = db.tableDao()
    private val productDao = db.productDao()
    private val itemDao = db.itemDao()
    private val saleDao = db.saleDao()

    fun observeTables() = tableDao.observeAll()
    fun observeAllItems() = itemDao.observeAll()
    fun observeProducts() = productDao.observeActive()
    fun observeSales(from: Long, to: Long) = saleDao.observeBetween(from, to)
    fun observeTopProducts(from: Long, to: Long) = saleDao.observeTopProducts(from, to)
    fun observeSummary(pattern: String, offset: Long, from: Long, to: Long) =
        saleDao.observeSummary(pattern, offset, from, to)

    suspend fun getSale(id: Long) = saleDao.getSale(id)
    suspend fun getSaleItems(saleId: Long) = saleDao.itemsFor(saleId)

    // ---- Backup ---------------------------------------------------------

    suspend fun exportBackup(settings: AppSettings, now: Long): String =
        Backup.export(db, settings, now)

    suspend fun importBackup(text: String): Backup.Restored = Backup.restore(db, text)

    // ---- Tables ---------------------------------------------------------

    suspend fun seedIfEmpty(counterName: String, tablePrefix: String, bigRate: Int, smallRate: Int) {
        if (tableDao.count() > 0) return
        val plan = listOf(
            TableSize.BIG to bigRate,
            TableSize.BIG to bigRate,
            TableSize.SMALL to smallRate,
            TableSize.SMALL to smallRate
        )
        plan.forEachIndexed { i, (size, rate) ->
            tableDao.insert(
                BilliardTable(
                    name = "$tablePrefix ${i + 1}",
                    ratePerHour = rate,
                    sortOrder = i,
                    size = size.name
                )
            )
        }
        tableDao.insert(
            BilliardTable(name = counterName, ratePerHour = 0, isCounter = true, sortOrder = 999)
        )
    }

    suspend fun addTable(name: String, size: TableSize, ratePerHour: Int) {
        val order = tableDao.maxSortOrder() + 1
        tableDao.insert(
            BilliardTable(name = name, ratePerHour = ratePerHour, sortOrder = order, size = size.name)
        )
    }

    suspend fun updateTable(table: BilliardTable) = tableDao.update(table)

    /** Changes the hourly rate of every table of [size]. Running sessions keep their locked rate. */
    suspend fun applyRate(size: TableSize, rate: Int) = tableDao.setRateForSize(size.name, rate)

    /** Returns false when the table is in use and therefore cannot be deleted. */
    suspend fun deleteTable(table: BilliardTable): Boolean = db.withTransaction {
        val fresh = tableDao.get(table.id) ?: return@withTransaction true
        if (fresh.isCounter || fresh.startTime != null || itemDao.getFor(fresh.id).isNotEmpty()) {
            return@withTransaction false
        }
        tableDao.delete(fresh)
        true
    }

    /** Starts the clock and locks the table's current hourly rate for this session. */
    suspend fun startTable(id: Long, now: Long) = db.withTransaction {
        val table = tableDao.get(id) ?: return@withTransaction
        if (table.isCounter || table.startTime != null) return@withTransaction
        tableDao.startSession(id, now, table.ratePerHour)
    }

    // ---- Running bill ---------------------------------------------------

    /** Adds one unit of [product]. Returns false when tracked stock is insufficient. */
    suspend fun addItem(tableId: Long, product: Product): Boolean = db.withTransaction {
        val fresh = productDao.get(product.id) ?: return@withTransaction false
        val existing = itemDao.find(tableId, fresh.id)
        val newQty = (existing?.qty ?: 0) + 1
        if (fresh.trackStock && newQty > fresh.stock) return@withTransaction false
        if (existing == null) {
            itemDao.insert(
                TableItem(
                    tableId = tableId,
                    productId = fresh.id,
                    name = fresh.name,
                    price = fresh.price,
                    qty = 1
                )
            )
        } else {
            itemDao.update(existing.copy(qty = newQty))
        }
        true
    }

    /** Changes quantity by [delta]; removes the line at zero. Returns false on insufficient stock. */
    suspend fun changeQty(item: TableItem, delta: Int): Boolean = db.withTransaction {
        val newQty = item.qty + delta
        if (newQty <= 0) {
            itemDao.deleteById(item.id)
            return@withTransaction true
        }
        if (delta > 0) {
            val product = productDao.get(item.productId)
            if (product != null && product.trackStock && newQty > product.stock) {
                return@withTransaction false
            }
        }
        itemDao.update(item.copy(qty = newQty))
        true
    }

    /** Discards the running bill without recording a sale. */
    suspend fun cancelSession(tableId: Long) = db.withTransaction {
        itemDao.clearFor(tableId)
        tableDao.endSession(tableId)
    }

    // ---- Checkout -------------------------------------------------------

    /** Closes the running bill, stores it as a [Sale] and returns the sale id. */
    suspend fun checkout(tableId: Long, discount: Int, now: Long): Long = db.withTransaction {
        val table = tableDao.get(tableId) ?: error("Table not found")
        val items = itemDao.getFor(tableId)
        val start = table.startTime
        val timed = !table.isCounter && start != null

        val minutes = if (timed && start != null) Billing.minutes(start, now) else 0
        val play = if (timed) Billing.playAmount(table.billingRate(), minutes) else 0
        val itemsAmount = items.sumOf { it.price * it.qty }
        val gross = play + itemsAmount
        val appliedDiscount = discount.coerceIn(0, gross)

        val saleId = saleDao.insertSale(
            Sale(
                tableName = table.name,
                startTime = if (table.isCounter) null else start,
                endTime = now,
                minutes = minutes,
                playAmount = play,
                itemsAmount = itemsAmount,
                discount = appliedDiscount,
                total = gross - appliedDiscount,
                createdAt = now
            )
        )
        saleDao.insertItems(
            items.map { SaleItem(saleId = saleId, name = it.name, price = it.price, qty = it.qty) }
        )
        items.forEach { productDao.decrementStock(it.productId, it.qty) }
        itemDao.clearFor(tableId)
        tableDao.endSession(tableId)
        saleId
    }

    // ---- Products -------------------------------------------------------

    suspend fun saveProduct(product: Product) {
        if (product.id == 0L) productDao.insert(product) else productDao.update(product)
    }
}

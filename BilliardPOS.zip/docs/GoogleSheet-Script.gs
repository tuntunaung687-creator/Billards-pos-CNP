// Billiard POS -> Google Sheet receiver.
// 1) Change TOKEN below to your own secret word (same word goes in the app's Settings).
// 2) Deploy > New deployment > Web app > Execute as: Me, Who has access: Anyone.
var TOKEN = 'CHANGE_ME';
var SHEET_ID = 'PASTE_SHEET_ID_HERE';

function out(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function sheet(ss, name, header) {
  var sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.appendRow(header);
    sh.setFrozenRows(1);
    sh.getRange('B:B').setNumberFormat('@'); // keep "2026-11" as text
  }
  return sh;
}

function ensureSummary(ss) {
  if (ss.getSheetByName('လချုပ်')) return;
  var sh = ss.insertSheet('လချုပ်', 0);
  sh.getRange('A1').setFormula(
    '=QUERY(Bills!A2:K,"select B, count(A), sum(F), sum(G), sum(H), sum(I), sum(J) ' +
    'where A is not null group by B order by B desc ' +
    'label B \'လ\', count(A) \'ဘောက်ချာ\', sum(F) \'ခုံကြေး\', sum(G) \'မာကာကြေး\', ' +
    'sum(H) \'အခြားရောင်းရငွေ\', sum(I) \'လျှော့ငွေ\', sum(J) \'စုစုပေါင်း\'",1)');
  sh.getRange('A20').setFormula(
    '=QUERY(MarkerPay!A2:F,"select B, C, sum(D), sum(E) where A is not null ' +
    'group by B, C order by B desc ' +
    'label B \'လ\', C \'မာကာ\', sum(D) \'မိနစ်\', sum(E) \'ရသင့်ငွေ\'",1)');
}

function doPost(e) {
  var d;
  try { d = JSON.parse(e.postData.contents); } catch (err) { return out({ok: false, error: 'json'}); }
  if (d.token !== TOKEN) return out({ok: false, error: 'token'});

  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var ss = SpreadsheetApp.openById(SHEET_ID);
    var bills = sheet(ss, 'Bills', ['ဘောက်ချာ', 'လ', 'ရက်/အချိန်', 'ခုံ', 'မိနစ်',
      'ခုံကြေး', 'မာကာကြေး', 'အခြားရောင်းရငွေ', 'လျှော့ငွေ', 'စုစုပေါင်း', 'ဝန်ထမ်း']);
    var pay = sheet(ss, 'MarkerPay', ['ဘောက်ချာ', 'လ', 'မာကာ', 'မိနစ်', 'ရသင့်ငွေ', 'ရက်/အချိန်']);
    ensureSummary(ss);

    var seen = {};
    var last = bills.getLastRow();
    if (last > 1) bills.getRange(2, 1, last - 1, 1).getValues().forEach(function (r) { seen[r[0]] = true; });
    var newBills = (d.bills || []).filter(function (r) { return !seen[r[0]]; });
    if (newBills.length) bills.getRange(bills.getLastRow() + 1, 1, newBills.length, 11).setValues(newBills);

    var seenPay = {};
    last = pay.getLastRow();
    if (last > 1) pay.getRange(2, 1, last - 1, 3).getValues().forEach(function (r) { seenPay[r[0] + '|' + r[2]] = true; });
    var newPay = (d.markerPay || []).filter(function (r) { return !seenPay[r[0] + '|' + r[2]]; });
    if (newPay.length) pay.getRange(pay.getLastRow() + 1, 1, newPay.length, 6).setValues(newPay);

    return out({ok: true, bills: newBills.length, markerPay: newPay.length});
  } catch (err) {
    return out({ok: false, error: String(err)});
  } finally {
    lock.releaseLock();
  }
}

function doGet() { return out({ok: true, msg: 'Billiard POS receiver'}); }
